import os
import sys
import struct
import string
import bin_struct
import re
import shutil

# Error data
RAM_START  = 0x1FFFE000
RAM_SIZE   = 0x8000
ERR_OFFSET = 0x20005F00
ERR_SIZE = 256

ERR_OFFSET_REL = ERR_OFFSET - RAM_START

BUILD_DIRECTORY = r'\\bombay\data\PROJECTS\Consumer\Fitness\Wellness\Vivo_Smart\Software\current_boards'

# Error defines
ERR_VALID_KEY = 0x5f3759df
UTL_HASH_SIZE = 40
UTL_ASSERT_MAX_STACK_PTR_DEPTH = 20
MAX_RAM_ERROR_SIZE = 100
UTL_ASSERT_MAX_FILE_NAME = 32
UTL_ASSERT_MAX_AUX = 32
UTL_NUM_RTL_REGS = 16

# UTL_err_id enum
UTL_ERR_ABNORMAL_PWRDN          =   0      # Abnormal Powerdown
# error and spurious vectors
UTL_FAULT_START                 =   1      #
UTL_ERR_NMI                     =   1      # Non-maskable Interrupt
UTL_ERR_HARD_FAULT              =   2      # Hard Fault
UTL_ERR_MEM_FAULT               =   3      # Memory Fault
UTL_ERR_BUS_FAULT               =   4      # Bus Fault
UTL_ERR_USAGE_FAULT             =   5      # Usage Fault
UTL_ERR_SVC                     =   6      # Supervisor Call Interrupt
UTL_ERR_DEBUG_MON               =   7      # Debug Monitor
UTL_ERR_SYS_TICK                =   8      # System Tick Interrupt
UTL_ERR_UNDEF_VCTR              =   9      # Spurious Interrupt
UTL_FAULT_END                   =   9      #
# assert
UTL_ERR_ASSERT                  =  10      # Software Assert
# rtl
UTL_ERR_RTL_TRAP                =  11      # RTL trap


# Structure declarations
members = "key@L time@L data@{0}s".format(MAX_RAM_ERROR_SIZE)
utl_ram_error_type = bin_struct.struct_class( "utl_ram_error_type", members )

members = "error@{0}s hash@{1}s dirty@? log_mhndls@? pad@2s psp_addr@L reg_lr@L uptime@L \
call_stack@{2}L".format( utl_ram_error_type.SIZEOF, UTL_HASH_SIZE, UTL_ASSERT_MAX_STACK_PTR_DEPTH )
utl_aux_error_type = bin_struct.struct_class( "utl_aux_error_type", members )

members = "err_id@B pad@3s err_addr@L stack_addr@L link_reg@L"
utl_exptn_log_type = bin_struct.struct_class( "utl_exptn_log_type", members )

members = "pad@2s line_num@H stack_addr@L file_name_str@{0}s aux_str@{1}s".format( UTL_ASSERT_MAX_FILE_NAME, UTL_ASSERT_MAX_AUX )
utl_assert_log_type = bin_struct.struct_class( "utl_assert_log_type", members )

members = "err_id@B pad1@3s errnum@L num_regs@B pad2@3s reg@{0}L".format( UTL_NUM_RTL_REGS )
utl_rtl_log_type = bin_struct.struct_class( "utl_rtl_log_type", members )
del members


def get_build_directories():
    """Get directories containing sys.bin, sys.axf
    and da.exe"""
    dir_list = []
    for path in os.listdir( BUILD_DIRECTORY ):
        dir_list.append( os.path.join( BUILD_DIRECTORY, path ) )
    dir_list.append( '.' )
    return dir_list

def get_hashes_mappings():
    # TODO, opt - cached a version of the hash mappings on the network
    hash_to_dir = {}
    pattern = re.compile("[0-9a-f]{40}")
    for build_dir in get_build_directories():
        sys_file_name = os.path.join( build_dir, "sys.bin" )
        if os.path.isfile( sys_file_name ):
            f = open( sys_file_name, "rb" )
            contents = f.read()
            f.close()
            result = pattern.findall( contents )
            if len(result) == 1:
                hash_to_dir[result[0]] = build_dir
    return hash_to_dir

def find_build_dir_from_hash( git_sha ):
    if git_sha in hash_to_build_dir:
        return hash_to_build_dir[git_sha]

def fmt_null_string( data ):
    start = string.find( data, '\0' )
    if start >= 0:
        return data[0:start]
    else:
        return data

# Run dump analyzer
def do_da( file, build_dir, output_dir, csp ):
    src_sys_bin = os.path.join( build_dir, "sys.bin" )
    src_sys_axf = os.path.join( build_dir, "sys.axf" )
    src_ram = file
    src_da = os.path.join( build_dir, "da.exe" )

    dst_sys_bin = os.path.join( output_dir, "ROM_0x00000800.bin" )
    dst_sys_axf = os.path.join( output_dir, "sys.axf" )
    dst_ram = os.path.join( output_dir, "RAM_0x1fffe000.BIN" )
    dst_da = os.path.join( output_dir, "da.exe" )

    shutil.copy(src_sys_bin, dst_sys_bin)
    shutil.copy(src_sys_axf, dst_sys_axf)
    shutil.copy( src_da, dst_da)
    shutil.copy( src_ram, dst_ram)

    da_bat = os.path.join( output_dir, "da.bat" )
    f = open( da_bat, "wb" )
    f.write("da.exe sys.axf RAM_0x1fffe000.BIN ROM_0x00000800.bin -csp 0x{0:08x} > da_output.txt 2>&1".format(csp))
    f.close()

    cwd = os.getcwd()
    os.chdir( output_dir )
    os.system( "da.bat > NUL" )
    os.chdir( cwd )

def parse_error( dump_file_name, output_dir, find_build_dir_from_hash_funct ):

    # Read file contents
    f = open(dump_file_name, "rb")
    file_contents = f.read()
    f.close()
    if len(file_contents) < RAM_SIZE:
        return False
    error_data = file_contents[ERR_OFFSET_REL:ERR_OFFSET_REL+ERR_SIZE]

    # Parse data into structs
    utl_aux_error = utl_aux_error_type()
    utl_aux_error.unpack( error_data )

    utl_ram_error = utl_ram_error_type()
    utl_ram_error.unpack( utl_aux_error.error )
    utl_ram_error.err_id = struct.unpack('<B', utl_ram_error.data[0:1])[0]

    utl_exptn_log = utl_exptn_log_type()
    utl_exptn_log.unpack( utl_ram_error.data )

    utl_assert_log = utl_assert_log_type()
    utl_assert_log.unpack( utl_ram_error.data )

    utl_rtl_log = utl_rtl_log_type()
    utl_rtl_log.unpack( utl_ram_error.data )

    # Print out data
    if utl_ram_error.key == ERR_VALID_KEY:

        # Create output file
        if not os.path.exists(output_dir): os.makedirs(output_dir)
        output_file_name = os.path.join( output_dir, "err_log.txt" )
        f = open(output_file_name, "wb")
        def write( data ):
            f.write( data )
            f.write( "\r\n" )

        build_dir =  find_build_dir_from_hash_funct( utl_aux_error.hash )
        if utl_aux_error.dirty:
            write( "Commit: {0}*".format( utl_aux_error.hash ) )
        else:
            write( "Commit: {0}".format( utl_aux_error.hash ) )

        if build_dir:
            write( "Build dir: {0}".format( build_dir ) )
        else:
            write( "Could not find system image" )
        write( "Time: {0}".format( utl_ram_error.time ) )

        if utl_ram_error.err_id == UTL_ERR_ASSERT:
            write( "Assert" )
            write( "{0} line {1}".format( fmt_null_string(utl_assert_log.file_name_str), utl_assert_log.line_num ) )
        elif utl_ram_error.err_id == UTL_ERR_RTL_TRAP:
            write( "RTL Trap" )
            write( "errnum: 0x{0:08x}".format( utl_rtl_log.errnum ) )
            for i in range( utl_rtl_log.num_regs ):
                write( "r{0}: 0x{1:08x}".format( i, utl_rtl_log.reg[i] ) )
        elif utl_ram_error.err_id >= UTL_FAULT_START and utl_ram_error.err_id <= UTL_FAULT_END:
            write( "Hard Fault" )
            write( "PC: 0x{0:08x}".format( utl_exptn_log.err_addr ) )
            write( "LR: 0x{0:08x}".format( utl_exptn_log.link_reg ) )
            write( "SP: 0x{0:08x}".format( utl_exptn_log.stack_addr ) )
        elif utl_ram_error.err_id == UTL_ERR_ABNORMAL_PWRDN:
            write( "Abnormal powerdown" )
        else:
            write( "Unknown error {0}".format( utl_ram_error.err_id ) )

        write( "Call Stack - PSP at 0x{0:08x}".format( utl_aux_error.psp_addr ) )
        for addr in utl_aux_error.call_stack:
            write( "\t0x{0:08x}".format( addr ) )
        write( "Uptime: {0}".format( utl_aux_error.uptime ) )

        if build_dir:
            ( filename, ext ) = os.path.splitext( dump_file_name )
            do_da( dump_file_name, build_dir ,filename, utl_aux_error.psp_addr )

        if f is not None:
            f.close()

    return utl_ram_error.key == ERR_VALID_KEY

if __name__ == "__main__":
    hash_to_build_dir = get_hashes_mappings()
    if len(sys.argv) <= 1:
        print( "Processing files in current directory:" )
        print("")
        for filename in os.listdir("."):
            ( name, ext ) = os.path.splitext( filename )
            ext = ext.lower()
            if ext == ".bin":
                output_dir = name
                if parse_error( filename, output_dir, find_build_dir_from_hash ):
                    print( "{0:20} -> {1}".format( filename, output_dir ) )
    else:
        # A file was explicitly specified so only process it
        parse_error( sys.argv[1], find_build_dir_from_hash )
