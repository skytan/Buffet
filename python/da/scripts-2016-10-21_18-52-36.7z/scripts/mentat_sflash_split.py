usage = """
mentat_sflash_split.py <sflash.bin>

Split a mentat serial flash image into individual regions
You can download the sflash contents entirely by holding
in boot block and doing 'rrgn_usb /R123 /Fbin sflash.bin'
"""
import binascii
import os
import os.path
import struct
import sys

def is_erased( data ):
    for s in data:
        if ord(s) != 0xFF:
            return False
    return True

def run_cmd( cmd ):
    print "system", repr( cmd )
    os.system( cmd )

def fs_handler( subdir, fname ):
    #unl2p the file
    l2p_py_file = os.path.join( "..", "TFS", "l2p_tools", "unl2p.py" )
    rgn_file_path = os.path.join( subdir, fname )
    fat_file_path = os.path.join( subdir, fname + ".unl2p.bin" )
    run_cmd( " ".join( ( "python", l2p_py_file, rgn_file_path, fat_file_path ) ) )

    #Extract files to local file system in the "subdir/FS" directory
    fat_extract_dir = os.path.join( subdir, "FS_root" )
    run_cmd( " ".join( ( "python", "fat.py", fat_file_path, "-x", fat_extract_dir ) ) )

def journal_handler( subdir, sflash_data, journal_name, replay_name ):
    """
    First 8 bytes is "JOURNAL1"
    Next is entries of this
    typedef __packed_struct
        {
        uint32 byte_offset;
        uint8  erase_cmd;
        uint32 checksum;
        } journal_entry_t;
    """
    hwm_SFLASH_SECTOR_ERASE = ( 0x20 )  #4k
    hwm_SFLASH_BLOCK_ERASE  = ( 0xD8 )  #64k

    f = open( os.path.join( subdir, journal_name ), 'rb' )
    jdata = f.read()
    f.close()

    sflash_data = [ ord(s) for s in sflash_data ]

    idx = 0
    #Look for erase journal header
    hdr = jdata[idx:idx+8]
    if "JOURNAL1" != hdr:
        print "JOURNAL header DNE, found", binascii.hexlify(hdr)
    else:
        print "FOUND JHEADER"

    #Look for erase journal entries
    idx += 8
    entry_format = "<IBI"
    entry_size = struct.calcsize( entry_format )
    while True:
        try:
            entry = jdata[idx:idx+entry_size]
            offset, cmd, checksum = struct.unpack( entry_format, entry )
        except:
            raise
        if is_erased( entry ):
            print "Found erased journal entry at index", idx
            break
        if ( ( offset + cmd ) & 0xFFFFFFFF ) != checksum:
            print "Found corrupt journal entry at index", idx
            break
        print "FOUND JENTRY at idx", idx, "offset", hex(offset), "cmd", hex(cmd), "csum", hex(checksum)
        idx += entry_size

        #Apply the journaled erase
        size = 4 * 1024
        if cmd == hwm_SFLASH_BLOCK_ERASE:
            size = 64 * 1024
        for i in range( offset, offset+size ):
            sflash_data[i] = 0xFF

    #write sflash data with journal erases applied to a file
    f = open( os.path.join( subdir, replay_name ), 'wb' )
    f.write( "".join( [ chr(x) for x in sflash_data ] ) )
    f.close()

def nonvol_handler( subdir, fname ):
    #Run nv report
    nvm_file_path = os.path.join( subdir, fname )
    nv_rpt_file_path = os.path.join( subdir, fname + ".txt" )
    run_cmd( " ".join( ( "python", "nvm_parse.py", "-i", nvm_file_path, "-r", nv_rpt_file_path ) ) )

def ram_dump_handler( subdir, fname ):
    #Run dump analyze if the dump file is not erased
    curdir = os.getcwd()
    da_py_file = os.path.join( curdir, "dump_analyze.py" )
    os.chdir( subdir )
    infile = open( fname, 'rb' )
    data = infile.read()
    infile.close()
    if not is_erased( data ):
        run_cmd( " ".join( ( "python", da_py_file, fname ) ) )
    else:
        print "Dump all erased"
    os.chdir( curdir )

class Region( object ):
    def __init__( self, name, size, offset = 0, handler = None ):
        self.name = name
        self.size = size
        self.offset = offset
        self.handler = handler

#Regions
KB = 1024

boot_block  = Region( "BB", 12 * KB )
system      = Region( "SYS_0x00000800", 256 * KB )
nonvol      = Region( "NONVOL", 8 * KB )
text_lang   = Region( "TEXT_LANG", 4 * KB )
tsc         = Region( "TSC", 64*KB )
bios        = Region( "BIOS_REGION", 4*KB )
erase_journal = Region( "ERASE_JOURNAL", 4*KB )
ram_dump    = Region( "RAM_DUMP_0x1FFFE000", 32*KB )
unused      = Region( "GMAP_TZ_UNUSED", 268*KB )
fs          = Region( "FS", 1396*KB )

layout = ( boot_block, system, nonvol, text_lang, tsc, bios, erase_journal, ram_dump, unused, fs )

#main
if len(sys.argv) < 2:
    print usage
    sys.exit(-1)

subdir = sys.argv[1] + "_dir"
if not os.path.exists( subdir ):
    os.mkdir( subdir )

if not os.path.isdir( subdir ):
    print "my subdir isn't a dir"
    sys.exit(-2)

#calculate region offsets
offset = 0
for rgn in layout:
    rgn.offset = offset
    offset += rgn.size

#Read in sflash dump
filename = sys.argv[1]
f = open( filename, 'rb')
contents = f.read()
f.close()

#Parse regions
for rgn in layout:
    rgn_filename = rgn.name + ".bin"
    rgn_file_path = os.path.join( subdir, rgn_filename )
    dump_file = open( rgn_file_path, "wb" )
    dump_file.write(contents[rgn.offset:rgn.offset+rgn.size])
    dump_file.close()

#Replay erase journal over original sflash data 'contents'
replay_name = "journal_replay.bin"
journal_handler( subdir, contents, erase_journal.name + ".bin", replay_name )

#reparse replayed sflash dump
f = open( os.path.join( subdir, replay_name ), 'rb' )
contents = f.read()
f.close()

for rgn in layout:
    rgn_filename = rgn.name + ".bin"
    rgn_file_path = os.path.join( subdir, rgn_filename )
    dump_file = open( rgn_file_path, "wb" )
    dump_file.write(contents[rgn.offset:rgn.offset+rgn.size])
    dump_file.close()

nonvol_handler( subdir, nonvol.name + ".bin" )
ram_dump_handler( subdir, ram_dump.name + ".bin" )
fs_handler( subdir, fs.name + ".bin" )



