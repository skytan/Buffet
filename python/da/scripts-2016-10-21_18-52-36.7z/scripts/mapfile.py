#*********************************************************************
#
#   MODULE NAME:
#       mapfile.py - [title]
#
#   DESCRIPTION:
#       Classes that parse a map file from ARM or GNU linkers
#
#   PUBLIC PROCEDURES:
#       Name                    Title
#       ----------------------- --------------------------------------
#
#   PRIVATE PROCEDURES:
#       Name                    Title
#       ----------------------- --------------------------------------
#
#   LOCAL PROCEDURES:
#       Name                    Title
#       ----------------------- --------------------------------------
#
# Copyright 2012-2014 by Garmin Ltd. or its subsidiaries.
#---------------------------------------------------------------------
# $Log[10]:
# $
# $NoKeywords$
#********************************************************************/

#---------------------------------------------------------------------
#                             INCLUDES
#---------------------------------------------------------------------
import bisect
#from    collections import defaultdict
import sys
import re

#---------------------------------------------------------------------
#                             CONSTANTS
#---------------------------------------------------------------------

#---------------------------------------------------------------------
#                             VARIABLES
#---------------------------------------------------------------------

#---------------------------------------------------------------------
#                               MACROS
#---------------------------------------------------------------------

#---------------------------------------------------------------------
#                             PROCEDURES
#---------------------------------------------------------------------

class Region( object ):
    EXECUTION = "Execution"
    LOAD = "Load"
    KIND_NAMES = (  EXECUTION,
                    LOAD )

    def __init__( self, kind, name, base, size, max ):
        self.kind = kind
        self.name = name
        self.base = base
        self.size = size
        self.max = max

    def __str__( self ):
        return "%s,%s,0x%08X,0x%08X,0x%08X" % ( self.kind, self.name, self.base, self.size, self.max )


class Symbol( object ):
    #-------------------------------------------------------
    # kinds of symbols
    #-------------------------------------------------------
    ARM_CODE    = "ARM Code"
    THUMB_CODE  = "Thumb Code"
    DATA        = "Data"
    SECTION     = "Section"
    NUMBER      = "Number"
    REMOVED     = "Removed"

    KIND_NAMES = (  ARM_CODE,
                    THUMB_CODE,
                    DATA,
                    SECTION,
                    NUMBER,
                    REMOVED )
    max_kind_name_len = max( [ len(n) for n in KIND_NAMES ] )

    def __init__( self, name, addr=0, kind="", size=0, source="unknown_source" ):
        self.name = name
        self.addr = addr
        self.kind = kind
        self.size = size
        self.source = source
        self.end  = addr + size

    def in_range( self, addr ):
        return (addr >= self.addr and addr < self.end)

    def format( self, source_len=30, csv=False ):
        if csv:
            s = "%s,0x%08x,%u,%s,%s" % ( self.kind, self.addr, self.size, self.source, self.name )
        else:
            s = "%*s 0x%08x %8u %-*s %s " % ( Symbol.max_kind_name_len, self.kind, self.addr, self.size, source_len, self.source, self.name )
        return s

    def format_era( self ):
        s = "%s,0x%08x,0x%08x,%s" % ( self.name, self.addr, self.size, self.source )
        return s

    def __str__( self ):
        return self.format()

    def get_name( self ):
        return self.name

    def get_offset( self, addr ):
        return addr - self.addr

class MapFile( object ):
    @staticmethod
    def create( infile ):
        arm = ArmMapFile( infile )
        gnu = GnuMapFile( infile )
        if len( arm.symbols ) > len( gnu.symbols ):
            return arm
        return gnu

    def __init__( self, infile ):
        self.symbols = []
        self.regions = []

        #Parse map file data
        self.symbols, self.regions = self._parse( infile )

        # sort symbols list by address
        self.symbols.sort( lambda a,b: cmp( a.addr, b.addr ) )
        self.symbol_addrs = [ s.addr for s in self.symbols ]

    def _parse( self ):
        #Subclass will do this
        return [], []

    def _generate_era_symbol_file( self, f ):
        for s in self.symbols:
            if s.kind in ( Symbol.ARM_CODE, Symbol.THUMB_CODE, Symbol.DATA ):
                f.write( s.format_era() + "\n" )

    def generate_era_symbol_file( self, filename ):
        f = open( filename, "w" );
        self._generate_era_symbol_file( f )
        f.close()

    def print_symbols( self ):
        max_source_len = max( [ len( s.source ) for s in self.symbols ] )
        for s in self.symbols:
            print s.format( max_source_len, csv=False )

    def lookup_region_name( self, region_name, kinds=None ):
        if kinds is None:
            kinds = Region.KIND_NAMES

        for r in self.regions:
            if region_name == r.name and r.kind in kinds:
                return r

        return None

    def lookup_symbol_addr( self, addr, kinds=None ):
        if not self.symbols:
            return None

        #TODO: Add kinds filter
        #if kinds is None:
        #    kinds = Symbol.KIND_NAMES

        idx = bisect.bisect( self.symbol_addrs, addr ) - 1
        idx = max( idx, 0 )
        return self.symbols[ idx ]

    def lookup_symbol_name( self, symbol_name, kinds=None ):
        if kinds is None:
            kinds = Symbol.KIND_NAMES

        ret = []
        for s in self.symbols:
            if s.name == symbol_name and s.kind in kinds:
                ret.append( s )

        return ret

class ArmMapFile( MapFile ):
    source_regex = re.compile( r"(.*)[(].*[)]" )

    test_data = """
        i.gps_pps_updt                           0x805c3a34   Section       16  GPS_dr_io.c.6.o(i.gps_pps_updt)
        i.gps_proc_input                         0x805c3a44   Section       40  gps_input.c.6.o(i.gps_proc_input)
        i.gps_proc_prdc_warm_strt                0x805c3a6c   Section      596  gps_prdc_warm_strt.c.6.o(i.gps_proc_prdc_warm_strt)
        i.gps_prop_state                         0x805c3cc0   Section      676  gps_stat.c.6.o(i.gps_prop_state)
        i.gps_psn_meas                           0x805c3f64   Section      216  gps_main.c.6.o(i.gps_psn_meas)
        i.gps_pwrp_config                        0x805c403c   Section        4  gps_config.c.6.o(i.gps_pwrp_config)
        i.gps_pwrp_dst_data                      0x805c4040   Section       20  gps_odom_data.c.6.o(i.gps_pwrp_dst_data)
        gps_pps_updt                             0x805c3a35   Thumb Code    10  GPS_dr_io.c.6.o(i.gps_pps_updt)
        gps_proc_input                           0x805c3a45   Thumb Code    34  gps_input.c.6.o(i.gps_proc_input)
        gps_proc_prdc_warm_strt                  0x805c3a6d   Thumb Code   570  gps_prdc_warm_strt.c.6.o(i.gps_proc_prdc_warm_strt)
        gps_prop_state                           0x805c3cc1   Thumb Code   610  gps_stat.c.6.o(i.gps_prop_state)
        gps_psn_meas                             0x805c3f65   Thumb Code   210  gps_main.c.6.o(i.gps_psn_meas)
        gps_pwrp_config                          0x805c403d   Thumb Code     4  gps_config.c.6.o(i.gps_pwrp_config)
        gps_pwrp_dst_data                        0x805c4041   Thumb Code    16  gps_odom_data.c.6.o(i.gps_pwrp_dst_data)
        gps_pwrp_fix_flags                       0x805c4055   Thumb Code    14  gps_fix_flags.c.6.o(i.gps_pwrp_fix_flags)
        gps_pwrp_hdg_data                        0x805c4069   Thumb Code    34  gps_gyro_data.c.6.o(i.gps_pwrp_hdg_data)
        locate_thumbnail                         0x8060d303   Thumb Code   106  JPG_main.c.6.o(i.locate_thumbnail)
        log                                      0x8060d5b8   ARM Code      20  log.o(i.log)
        log10                                    0x8060d5cc   ARM Code      20  log10.o(i.log10)
        shell_transport_ptr$$Base                0x81bfe7f8   Number         0  shell_transport_iop_server.c.6.o(shell_transport_ptr)
        shell_transport_ptriop_transport_server  0x81bfe7f8   Data           4  shell_transport_iop_server.c.6.o(shell_transport_ptr)
        Image$$RAM_RWZI$$ZI$$Base                0x81bfe7fc   Number         0  anon$$obj.o(linker$$defined$$symbols)

      Image Entry point : 0x80100000

      Load Region PRIMARY (Base: 0x80100000, Size: 0x011e0cdc, Max: 0x01800000, ABSOLUTE)

        Execution Region GPS_RAM_RWZI (Base: 0x89899ca8, Size: 0x000c2310, Max: 0xffffffff, ABSOLUTE)

        Base Addr    Size         Type   Attr      Idx    E Section Name        Object

        0x89899ca8   0x00000008   Data   RW       141737    .data               gps_config.c.6.o
        0x89899cb0   0x0000000a   Data   RW       142357    .data               gps_debug_manager.c.6.o
        0x89899cba   0x00000002   PAD
    """
    @staticmethod
    def source_name( name ):
        """
        Remove junk from source file name
        """
        match = ArmMapFile.source_regex.match( name )
        if match:
            return match.group(1)
        return name

    def __init__( self, infile ):
        super( ArmMapFile, self ).__init__( infile )

    def _parse( self, infile ):
        #Parse map file data
        symbols = []
        regions = []
        kinds = "|".join( Symbol.KIND_NAMES )
        symbol_regex = re.compile( " +(?P<NAME>[^ ].+) +(?P<ADDR>0x[0-9a-fA-F]{8}) +(?P<KIND>%s) +(?P<SIZE>[0-9]+) +(?P<SOURCE>[^ ]+) *" % ( kinds, ) )
        region_regex = re.compile( " *(?P<KIND>Execution|Load) Region (?P<NAME>[^ ]+) [(]Base: (?P<BASE>0x[0-9A-Fa-f]{8}), Size: (?P<SIZE>0x[0-9A-Fa-f]{8}), Max: (?P<MAX>0x[0-9A-Fa-f]{8}),.*" )

        infile.seek( 0 )

        while True:
            line = infile.readline()
            if not line:
                break

            match = symbol_regex.match( line )
            if match:
                name   = match.group("NAME").strip()
                addr   = int( match.group("ADDR"), base=16 )
                kind   = match.group("KIND").strip()
                size   = int( match.group("SIZE"), base=10 )
                source = ArmMapFile.source_name( match.group("SOURCE").strip() )

                # Remove the Thumb lsb for Thumb Code symbols
                if kind == Symbol.THUMB_CODE:
                    addr = addr & (~1)

                s = Symbol( name, addr, kind, size, source )
                symbols.append( s )
                continue

            match = region_regex.match( line )
            if match:
                kind   = match.group("KIND")
                name   = match.group("NAME").strip()
                base   = int( match.group("BASE"), base=16 )
                size   = int( match.group("SIZE"), base=16 )
                max    = int( match.group("MAX"), base=16 )
                r = Region( kind, name, base, size, max )
                regions.append( r )
                continue

        return symbols, regions

class GnuMapFile2( MapFile ):
    def __init__( self, infile ):
        self.debug = False
        super( GnuMapFile, self ).__init__( infile )

    def _parse( self, infile ):
        #Trying to port the ERA parser which seemed more complete, didn't get very far
        section_regex = re.compile(r"^([A-Za-z_0-9-]+)\s+0x([0-9a-fA-F]+)\s+0x([0-9a-fA-F]+)\s+(load.*$|$)")
        comment_regex = re.compile(r"^ \.[a-zA-Z0-9_-]+\.([a-zA-Z0-9_-]+)(\.[a-zA-Z0-9_\.-]+)?\s*$")
        cut1_regex = re.compile(r"^ \.[a-zA-Z0-9_-]+\.([a-zA-Z0-9_-]+)(\.[a-zA-Z0-9_\.-]+)?\s*$")
        cut2_regex = re.compile(r"^\s+0x([0-9A-Fa-f]+).*0x([0-9A-Fa-f]+)\s+(.*(\\|\())?(.*(\..*obj|\.o))")
        cut3_regex = re.compile(r"^ \.[a-zA-Z0-9_-]+\.([a-zA-Z0-9_-]+)\s+0x([0-9A-Fa-f]+).*0x([0-9A-Fa-f]+).*(\\|\()(.*(\..*obj|\.o))")
        cut4_regex = re.compile(r"^ \.[a-zA-Z0-9-_]+\s+0x([0-9a-fA-F]+)\s+0x([0-9a-fA-F]+)\s+(.*(\\|\())?(.*(\..*obj|\.o))")
        cut5_regex = re.compile(r"^\s+0x([0-9a-fA-F]+)\s+([a-zA-Z0-9_-]+)\s*$")
        return [], []

class GnuMapFile( MapFile ):
    test_data = """             0x00001a84                ACT_hrm_get_heartrate_minute_avg
     .text.act_hrm_intf_update
                    0x00001aa4       0x60 ACT\\act_hrm_host.c.7.o
                    0x00001aa4                act_hrm_intf_update
     .text.act_hrm_intf_update_min
                    0x00001b04       0x3c ACT\\act_hrm_host.c.7.o
                    0x00001b04                act_hrm_intf_update_min
     .bss.data_csum
                    0x20003d79        0x1 iop_link.c.7.o
     .rodata.UTL_shft_tbl
                    0x00034020       0x20 utl_str.c.7.o

     .bss           0x00000000        0x0 ACT\\act_formulas.c.7.o
     .text.act_formula_test_output_table
                    0x00000000        0x4 ACT\\act_formulas.c.7.o
     .text          0x00000000        0x0 ACT\\act_hrm_host.c.7.o
     .data.bklght   0x00000000        0x4 HWM\\hwm_pmic_max14676.c.7.o
     .bss.accel_data.16422
                    0x00000000        0xc HWM\hwm_accel_lis2dh.c.7.o

    TSK_mem_pool_1  0x1fffe000     0x1000 load address 0x0002aa86
                    0x1fffe000                . = ALIGN (0x8)
                    0x1fffe000                PROVIDE (__start_TSK_mem_pool_1, ABSOLUTE (.))
     TSK_mem_pool_1
                    0x1fffe000     0x1000 TSK\\garmin-os\\tsk_init.c.7.o
                    0x1ffff000                PROVIDE (__stop_TSK_mem_pool_1, .)

    """
    def __init__( self, infile ):
        self.debug = False
        super( GnuMapFile, self ).__init__( infile )

    def _parse( self, infile ):
        FIND_NAME = 0
        FIND_NAME2 = 2
        FIND_SIZE = 1

        size_re = re.compile( "([.](?P<SECTION>[^.]*)[.])?(?P<SYMBOL>.*) +(?P<ADDR>0x[0-9A-Fa-f]{8}) *(?P<SIZE>0x[0-9A-Fa-f]+) +(?P<OBJECT>.*)" )

        sections = "text bss rodata data unknown".split()
        #Can't really tell difference between ARM and THUMB with GNU because it already
        #removes the LSB of the address which indicates a THUMB call, so go THUMB by default
        section_to_kind_map = { "text" : Symbol.THUMB_CODE, "bss":Symbol.DATA, "rodata":Symbol.DATA, "data":Symbol.DATA, "unknown":Symbol.DATA }
        infile.seek( 0 )
        state = FIND_NAME
        text = ""
        symbols = []
        regions = []    #not handled yet

        for line in infile:
            if FIND_NAME == state:
                text = line.strip()
                if self.debug:
                    print "LINE1", line
                    print "TEXT1", text

                #If there is only the name on the line, then append the next
                #line to this line before running the regex to find the sizes
                #'*' check removes lines like ' *(.bss.usb_buf_desc_table)'
                if line.startswith(' ') and ( not text.startswith('*') ) and len( text.split() ) == 1:
                    if not text.startswith( '.' ):
                        text = ".unknown." + text
                    state = FIND_NAME2
                    continue
                else:
                    state = FIND_SIZE

            if FIND_NAME2 == state:
                text += " " + line.strip()
                if self.debug:
                    print "LINE2", line
                    print "TEXT2", text
                state = FIND_SIZE

            if FIND_SIZE == state:
                match = size_re.match( text )
                if match:
                    if self.debug:
                        print "MATCH"
                    section = match.group( "SECTION" )
                    if section in sections:
                        symbol = match.group( "SYMBOL" ).strip()
                        size = int( match.group( "SIZE" ), base=16 )
                        addr = int( match.group( "ADDR" ), base=16 )
                        obj = match.group( "OBJECT" ).strip()
                        #only keep file name
                        p = obj.rfind( '/' )
                        if p < 0:
                            p = obj.rfind( '\\' )
                        if p > 0:
                            obj = obj[p+1:]
                        if 0 == addr:
                            #Not technically true always
                            kind = Symbol.REMOVED
                        else:
                            kind = section_to_kind_map[ section ]

                        s = Symbol( symbol, addr, kind, size, obj )
                        symbols.append( s )

                state = FIND_NAME
                text = ""

        return symbols, regions

def run_test( infile, flavor="unknown" ):
    """
    Run test using the infile as the source of data for the map file
    """
    print "_______{0}_______".format( flavor )
    test_file = StringIO.StringIO( infile )
    mf = MapFile.create( test_file )
    print "SYMBOLS"
    for s in mf.symbols:
        print s
    print ""
    print "REGIONS"
    for r in mf.regions:
        print r
    print ""
    print "ERA"
    era_file = StringIO.StringIO()
    mf._generate_era_symbol_file( era_file )
    era_file.seek(0)
    for line in era_file:
        print line,
    print "__________________"

if __name__ == "__main__":
    if len( sys.argv ) >= 2:
        mf = MapFile.create( open( sys.argv[1], 'r' ) )
        mf.print_symbols()
    else:
        #No args, run module test
        import StringIO
        run_test( ArmMapFile.test_data, "ARM" )
        run_test( GnuMapFile.test_data, "GNU" )
