import re
import struct

DEFAULT_PACKING = "<"
DEFAULT_DELIM = ","
DEFAULT_HIDE_PAD = True

"""
#True: Array output with one elem per delim.
#E.G> ra@3f = hdr: ra[0], ra[1], ra[2] data: val0, val1, val2,

#False: Array output with one array per delim
E.G> ra@3f = hdr: ra  data: [ val0, val1, val2 ],
"""
DEFAULT_SPLIT_ARRAY = True

class Member( object ):
    def __init__( self, name, format, index=0 ):
        self.name = name
        self.format = format
        self.index = index

    def is_array( self ):
        return self.index > 0 and self.format != 's'

    def is_pad( self ):
        return self.name.startswith( "_pad" )

    def pprint( self, label, value, label_len=0 ):
        """
        pretty print a single value
        """
        if type( value ) in ( int, long ):
            zero_len = struct.calcsize( self.format ) * 2
            return "%*s = 0x%0*X, %u\n" % ( label_len, label, zero_len, value, value )
        elif type( value ) == float:
            return "%*s = %f\n" % ( label_len, label, value )
        else: # type( value ) == str or anything else:
            return "%*s = %s\n" % ( label_len, label, str( value ) )

def struct_class( cls_name, cls_members, packing=DEFAULT_PACKING ):
    """
    Dyamically generate a class named cls_name that can unpack
    the desired struct format. All the member names cls_members
    should be of this format <name>@<n><format> where
    name    - a valid identifier
    n       - a decimal integer, omitted for non-array types
    format  - a python struct module format character

    If multiple members are in the structure, then each member
    should be followed by a space unless it is the last member.

    For example:
        string of 20 characters named hoser
        hoser@20s

        A single uint32 named foo
        foo@I

        cls_members = 'hoser@20s foo@I'
    """
    #The following defs are the methods that each generated
    #class will have
    def __init__( self, *args, **kwargs ):
        """
        struct_class generic constructor
        """
        #self.data = None
        for mem,arg in zip( self.MEMBERS, args ):
            #print "member", mem, "has arg", arg
            setattr( self, mem, arg )

        for mem in self.MEMBERS[len(args):]:
            val = 0
            if kwargs.has_key( mem ):
                #print "member", mem, "has kwarg", kwargs[mem]
                val = kwargs[mem]
            setattr( self, mem, val )

    def __str__( self ):
        return self.delimited( delim="\n", split_array=False )

    def delimited( self, delim=DEFAULT_DELIM, split_array=DEFAULT_SPLIT_ARRAY, hide_pad=DEFAULT_HIDE_PAD ):
        val_strs = []
        for member in self._MEMBERS:
            if hide_pad and member.is_pad():
                continue

            if split_array and member.is_array():
                ra = getattr( self, member.name )
                for v in ra:
                    val_strs.append( str( v ) )
            else:
                #MDB - scrub delim char out of val_strs when putting an array as a string??
                val_strs.append( str( getattr( self, member.name ) ) )


        return delim.join( val_strs )

    def header( self, delim=DEFAULT_DELIM, split_array=DEFAULT_SPLIT_ARRAY, hide_pad=DEFAULT_HIDE_PAD ):
        hdrs = []
        for member in self._MEMBERS:
            if hide_pad and member.is_pad():
                continue

            if split_array and member.is_array():
                for i in range( member.index ):
                    hdrs.append( "%s[%u]" % ( member.name, i ) )
            else:
                hdrs.append( member.name )

        return delim.join( hdrs )

    def pack( self ):
        """
        Return packed binary data or None if error
        """
        #Flatten all members including array
        values = []
        for member in self._MEMBERS:
            mem_val =  getattr( self, member.name )
            #append list if array, else append value
            if member.is_array():
                values += mem_val
            else:
                values.append( mem_val )

        try:
            d = struct.pack( self.FORMAT, *values )
        except:
            print "Couldn't pack struct for", self.__class__
            print "values:", values
            #raise #uncomment to see what the error was
            d = None
        return d

    def pprint( self, padding="" ):
        """
        pretty print values in struct
        """
        s = ""
        label_len = max( [ len( m.name ) for m in self._MEMBERS ] )
        for member,value in zip( self._MEMBERS, [ getattr( self, x ) for x in self.MEMBERS ] ):
            if member.is_array():
                index_text_len = len( str( member.index - 1 ) )
                for i,v in enumerate( value ):
                    s += padding
                    lbl = "%s[%*u]" % ( member.name, index_text_len, i )
                    s += member.pprint( lbl, v, label_len )
            else:
                s += padding
                s += member.pprint( member.name, value, label_len )
        return s

    def unpack( self, data ):
        """
        Unpack the struct and return the size of the data
        """
        d = data[:self.SIZEOF]
        if len(d) == self.SIZEOF:
            values = struct.unpack( self.FORMAT, d )
            for member in self._MEMBERS:
                if member.is_array():
                    vals = list( values[ : member.index ] )
                    setattr( self, member.name, vals )
                    values = values[ member.index : ]
                    #print "setting array", member.name, "to", vals
                else:
                    setattr( self, member.name, values[0] )
                    values = values[ 1: ]
                    #print "setting value", member.name, "to", vals

            #self.data = d  #MDB - need this?
            return self.SIZEOF
        return 0

    #class making code
    if type( cls_members ) == str:
        cls_members = cls_members.split()

    #Parse the member names and formats to make a struct
    cls_mem_regex = re.compile( r"^(?P<NAME>[^ ]+)@(?P<INDEX_FORMAT>(?P<INDEX>[1-9]+[0-9]*)?(?P<FORMAT>[cbB?hHiIlLqQfdspP]))$" )
    cls_format = packing
    internal_members = []
    external_members = []
    for name_and_format in cls_members:
        match = cls_mem_regex.match( name_and_format )
        if not match:
            raise ValueError( "invalid struct format: %s" % repr( name_and_format ) )

        index = match.group( "INDEX" )
        if index is None:
            index = 0
        else:
            index = int( index )

        member = Member(  match.group( "NAME" ), match.group("FORMAT"), index )
        cls_format += match.group( "INDEX_FORMAT" )
        external_members.append( member.name )
        internal_members.append( member )

    #Add class variables and methods to class members dictionary
    cls_dict = {}
    cls_dict[ "FORMAT" ]        = cls_format
    cls_dict[ "_MEMBERS" ]      = internal_members
    cls_dict[ "MEMBERS" ]       = external_members
    cls_dict[ "SIZEOF" ]        = struct.calcsize( cls_format )
    cls_dict[ "__init__" ]      = __init__
    cls_dict[ "__str__" ]       = __str__
    cls_dict[ "delimited" ]     = delimited
    cls_dict[ "header" ]        = header
    cls_dict[ "pack" ]          = pack
    cls_dict[ "pprint" ]        = pprint
    cls_dict[ "unpack" ]        = unpack

    #Create a new class
    cls = type( cls_name, (object,), cls_dict )
    return cls

import unittest
class ComplexStructTestCase( unittest.TestCase ):
    def setUp( self ):
        self.members = "carray character u8 u16 u32 u64 string afloat adouble barray _pad".split()
        self.format =  "<4ccBHIQ4sfd4BI"
        self.NewClass = struct_class( "NewClass", "carray@4c character@c u8@B u16@H u32@I u64@Q string@4s afloat@f adouble@d barray@4B _pad@I", packing="<" )

    def tearDown( self ):
        pass

    def runTest( self ):
        self.assertEqual( self.NewClass.FORMAT, self.format )
        self.assertEqual( self.NewClass.MEMBERS, self.members )
        self.assertEqual( self.NewClass.SIZEOF, struct.calcsize( self.format ) )

        mem = ( ['W', 'X', 'Y', 'Z'], "A", 0xA, 0x0100, 0x03020100, 0x0706050403020100, "str!", 0, 0, [0x30,0x31,0x32,0x33], 0xDDCCBBAA )
        mdict = dict()
        for k,v in zip( self.members, mem ):
            mdict[k] = v

        nc = self.NewClass()
        for m in self.members:
            self.assertEqual( 0, getattr( nc, m ) )

        #Unpack data into structure
        data = "WXYZA\x0A\x00\x01\x00\x01\x02\x03\x00\x01\x02\x03\x04\x05\x06\x07str!\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x30\x31\x32\x33\xAA\xBB\xCC\xDD"
        ret = nc.unpack( data )
        self.assertEqual( ret, self.NewClass.SIZEOF )
        self.assertEquals( ['W', 'X', 'Y', 'Z'], nc.carray )
        self.assertEquals( 'A', nc.character )
        self.assertEquals( 0x0A, nc.u8 )
        self.assertEquals( 0x0100, nc.u16 )
        self.assertEquals( 0x03020100, nc.u32 )
        self.assertEquals( 0x0706050403020100, nc.u64 )
        self.assertEquals( "str!", nc.string )
        self.assertEquals( 0, nc.afloat )
        self.assertEquals( 0, nc.adouble )
        self.assertEquals( [0x30,0x31,0x32,0x33], nc.barray )
        self.assertEquals( 0xDDCCBBAA, nc._pad )

        #Pack it back up, should match original
        pk = nc.pack()
        self.assertEquals( data, pk )

        #make struct using constructor with args
        nc = self.NewClass( *mem )
        pk = nc.pack()
        self.assertEquals( data, pk )

        #make struct using constructor with kwargs
        nc = self.NewClass( **mdict )
        pk = nc.pack()
        self.assertEquals( data, pk )

        print nc.pprint()
        print

        #manipulate some variables
        for i,v in enumerate( nc.barray ):
            nc.barray[i] = v + 4
        nc.string = "BOOF"
        nc.u32 =  0xF00BF00B

        #__str__ method
        print nc

        #csv output methods
        print nc.header()
        print nc.delimited()

        print nc.header( delim="," )
        print nc.delimited( delim="," )

class SimpleStructTestCase( unittest.TestCase ):
    def setUp( self ):
        self.members = [ "value" ]
        self.format =  "<I"
        self.NewClass = struct_class( "NewClass", "value@I", packing="<" )

    def tearDown( self ):
        pass

    def runTest( self ):
        self.assertEqual( self.NewClass.FORMAT, self.format )
        self.assertEqual( self.NewClass.MEMBERS, self.members )
        self.assertEqual( self.NewClass.SIZEOF, struct.calcsize( self.format ) )
        nc = self.NewClass()
        for m in self.members:
            self.assertEqual( 0, getattr( nc, m ) )

        data = "\x00\x01\x02\x03"
        ret = nc.unpack( data )
        self.assertEqual( ret, self.NewClass.SIZEOF )
        self.assertEquals( 0x03020100, nc.value )

        pk = nc.pack()
        self.assertEquals( data, pk )

        print nc.pprint()
        print

class BadStructFormatsTestCase( unittest.TestCase ):
    def setUp( self ):
        pass

    def tearDown( self ):
        pass

    def runTest( self ):
        bad_formats = ("_0938g@239ff"  ,   #extra f at the end
                       "_0938g@"       ,   #no format char at the end
                       "_0938g@fI"     ,   #extra format char at the end
                       "_0938g@0x390"  ,   #not decimal, no char at the end
                       "_0938g@0x390I" ,   #not decimal
                       "_0938g@0370I"  ,   #not decimal
                       "@0370I"        ,   #not named
                       "2039%0370I"    ,   #no @
                       "2039@f3"       ,   #number and format backward
                       "name"          ,   #just a name
                       " 8\ts 3 0 aa"  ,   #just names
                       "name"          ,   #just a name
                       "" )                #no format

        with self.assertRaises( ValueError ):
            for f in bad_formats:
                struct_class( "Fail_str", f )
                struct_class( "Fail_list", [ f ] )
                struct_class( "Fail_tuple", ( f ) )

if __name__ == "__main__":
    unittest.main()
