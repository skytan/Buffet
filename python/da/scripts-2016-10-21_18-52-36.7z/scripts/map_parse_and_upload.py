import sys
import os
import argparse
import subprocess

import mapfile

GPN_TO_PROD = {
    '006-B1956-00':'Mentat',
    '006-B1903-00':'Austin',
    '006-B2147-00':'Tandem',
    '006-B2238-00':'Tandem Basic',
    '006-B2148-00':'Twin Cities',
}

BUILD_TYPES = ('release', 'debug')
MAX_VERSION = 9.99 #any version higher than this is likely a mistake - like 214 instead of 2.14

parser = argparse.ArgumentParser(description='Process some integers.')
parser.add_argument('-m', '--map', default='sys.map', help='Map file to process')
parser.add_argument('-s', '--symbol', default='SYS_map_symbols.txt', help='Symbol file to output')
parser.add_argument('-u', '--upload', action='store_true', help='Upload to ERA')
parser.add_argument('-v', '--version', help='Version being uploaded, ex: 1.27')
parser.add_argument('-p', '--part', help='Software part number being uploaded ex: 006-B1903-00')
parser.add_argument('-b', '--build_type', default='release', help='Build type, typically "release" or "debug"')
parser.add_argument('-f', '--force', action='store_true', help='Force upload')
args = parser.parse_args()

map_file = args.map
symbol_file = args.symbol
upload = args.upload
software_part_num = args.part
version = args.version
package_type = args.build_type.lower()
force = args.force

# Generate Symbols file
f = open(map_file, "r")
mf = mapfile.MapFile.create( f )
mf.generate_era_symbol_file( symbol_file )

if upload:

    # A software part number must be specified
    if software_part_num is None:
        print('Missing software part number')
        exit()

    # A version must be specified
    if version is None:
        print('Missing software version')
        exit()

    # Version must be a float
    try:
        version_num = float(version)
    except:
        print('Invalid version %s' % version)
        exit()

    # Validate product
    if software_part_num in GPN_TO_PROD:
        product_name = GPN_TO_PROD[software_part_num]
    else:
        print('Unrecognized part number "%s"' % software_part_num)
        product_name = 'Unknown'
        if not force:
            exit()

    # Validate build type
    if not package_type in BUILD_TYPES:
        print('Unrecognized build type "%s"' % package_type)
        if not force:
            exit()

    # Validate version
    if version_num > MAX_VERSION:
        print('Version too large %s' % version)
        if not force:
            exit()

    print("Software part number: %s (%s)" % (software_part_num, product_name))
    print("Software version: %s" % str(version))
    print("Package type: %s" % package_type)
    print("Do you wish to continue with upload (y/n):")
    input = raw_input()
    if input.lower() == "y":
        subprocess.call(['perl.exe', '../post_map_prod.pl', software_part_num, version, symbol_file, package_type])
    else:
        print("Aborting upload")
