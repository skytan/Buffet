#!/c/Perl/bin/perl
#*********************************************************************
#
#   MODULE NAME:
#       all_build.pl -
#
#   DESCRIPTION:
#
# Copyright 2014 by Garmin Ltd. or its subsidiaries.
#
#*********************************************************************

use strict;
use warnings;
use Cwd;

# Stuff to make including from the current directory easy.
use Cwd 'abs_path';
use File::Basename;
use lib dirname( abs_path $0 );

use all_build_table;

#*********************************************************************
#
#   CONSTANTS
#
#*********************************************************************

#*********************************************************************
#
#   VARIABLES
#
#*********************************************************************
our @command_list;

#*********************************************************************
#
#   MAIN PROCESS
#
#*********************************************************************

main();
exit;

#*********************************************************************
#
#   SUBROUTINES
#
#*********************************************************************


#/*********************************************************************
#*
#*   PROCEDURE NAME:
#*       check_build_list - Examine and verify build list.
#*
#*   DESCRIPTION:
#*
#*********************************************************************/
sub check_build_list
{
my $array_ref;
my @build_list;
my @strings;
my $count;
my $result;

$array_ref = $_[0];
@build_list = @$array_ref;
$result = 0;
$count = 1;

print "Build list check...\n";
print "Build list count: " . @build_list . ".\n";
foreach( @build_list )
    {
    $array_ref = $_;
    @strings = @$array_ref;
    print "$count)\t";
    foreach( @strings )
        {
        print"$_ ";
        }
    print "\n";

    if( 3 != @strings )
        {
        print "Error - Incorrect number of strings in list entry.\n";
        $result = 1;
        }

    $count++;
    }
print "\n\n";

if( 0 != $result )
    {
    die "Error found in build table.  Script ending.\n";
    }

return $result;
}

#/*********************************************************************
#*
#*   PROCEDURE NAME:
#*       do_build - Execute a build.
#*
#*   DESCRIPTION:
#*
#*********************************************************************/
sub do_build
{
my $array_ref;
my @array;
my $product;
my $mode;
my $target;

$array_ref = $_[0];
@array = @$array_ref;
$product = $array[0];
$mode = $array[1];
$target = $array[2];

print "Product = $product, Mode = $mode, Target = $target.\n\n\n";

run_command("git clean -d -x -f");
run_command("waf.pl configure");
run_command("waf --product=$product --mode=$mode --target=$target");
}

#/*********************************************************************
#*
#*   PROCEDURE NAME:
#*       env_check - Check the environment in which this script is running.
#*
#*   DESCRIPTION:
#*
#*********************************************************************/
sub env_check
{
if(( length( $ENV{LOGNAME} )) && !( "" eq $ENV{LOGNAME} ))
    {
    print "The env var LOGNAME is '$ENV{LOGNAME}'.  This is an indication that this is running in a bash shell.\n";
    print "To function properly, this script must run from the windows command shell.\n";
    die "Script exiting.\n\n"
    }
else
    {
    print "Environment check OK.\n\n"
    }

return 0;
}

#/*********************************************************************
#*
#*   PROCEDURE NAME:
#*       main -
#*
#*   DESCRIPTION:
#*
#*********************************************************************/
sub main
{
my  @build_list;
my  $this_build;

@build_list = @all_build_table::build_table;

@command_list = "";


print "\n\n\n";
print "*********************************************************************\n";
print "Starting build-all.\n";
print "*********************************************************************\n";
print "\n\n\n";

os_check();

env_check();

check_build_list( \@build_list );

foreach( @build_list )
    {
    do_build($_);
    }

print "\n\nScript completed.  Commands run successfully:\n";
foreach( @command_list )
    {
    print "$_\n";
    }

return 0;
}# End of main.

#/*********************************************************************
#*
#*   PROCEDURE NAME:
#*       os_check - Operating system check
#*
#*   DESCRIPTION:
#*
#*********************************************************************/
sub os_check
{
my $OS_name;

$OS_name = $^O;
if(!( "MSWin32" eq "$OS_name" ))
    {
    die "This script cannot run from $OS_name.  It must be run from windows to work properly.\n\n";
    }
else
    {
    print "Script OS check okay.\n\n";
    }

return 0;
}

#/*********************************************************************
#*
#*   PROCEDURE NAME:
#*       run_command - Execute system command with error handling
#*
#*   DESCRIPTION:
#*
#*********************************************************************/
sub run_command
{
my @params;
my $command;
my $ret_val;
my $attempts;

@params = @_;
$command = $params[0];
$ret_val = 1;
$attempts = 2;

while(( 0 != $ret_val ) && ( 1 <= $attempts ))
    {
    push( @command_list, $command );

    print "Script executing command '$command'.\n\n";
    system("$command");
    $ret_val = $?;
    if( 0 != $ret_val )
        {
        print "In executing command '$command',\n";
        print "Got error code $?.\n";
        # Add a line to the command list indicating this command failed.
        # This is so the failure is visible in the event the overall
        # script succeeds.
        push( @command_list, "***FAILED***" );
        }
    else
        {
        print "Command '$command' completed successfully.\n";
        }

    $attempts--;
    }

if( 0 != $ret_val )
    {
    die;
    }

return $ret_val;
}
