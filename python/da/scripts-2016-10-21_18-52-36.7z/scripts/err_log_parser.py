help = """
Parse text error logs generated from exceptions on the device
and extract RAM dumps if they exist.
Typical use, just convert all dumps in err_log.txt to binary files
    'python err_log_parser.py'
or
    just double click the script
"""
from argparse     import ArgumentParser
from base64       import standard_b64decode as b64decode
from collections  import namedtuple, OrderedDict
from ctypes       import cdll
import os
import os.path
import re
from subprocess   import Popen
import sys

Dump = namedtuple( 'Dump', ['dev', 'ver', 'bld_type', 'filename', 'binary', 'ram_addr', 'SP', 'PC'] )
T32_install_path = os.path.join( 'C:', os.sep, 'T32', 'demo', 'api', 'python', 't32api.dll' )

# These are project specific
network_bld_loc = lambda dev: os.path.join( 'O:', os.sep, dev, 'bin' )
# LUT to map Build Type: entry to network location suffix
bld_type_suffix = { 'DEBUG': ' (Development)', 'RELEASE': '' }

def write_dump( dump ):
    if dump:
        with open( dump.filename, 'wb' ) as outfile:
            outfile.write( dump.binary )

def main():
    parser = ArgumentParser( description     = help )
    parser.add_argument( '-i', '--infile', nargs    = '?',
                                         type     = str,
                                         default  = 'ERR_LOG.txt',
                                         dest     = 'infile',
                                         help     = 'Device error log file to be parsed (default: %(default)s)' )

    parser.add_argument( '-o', '--outfile', nargs   = '?',
                                          type    = str,
                                          default = '',
                                          dest    = 'outfile',
                                          help    = 'RAM dump output file (default: mm_dd_yy_hh-mm-ss_RAM_0x{addr}.bin)' )

    parser.add_argument( '-s', '--suppress_date', action  = 'store_true',
                                                dest    = 'suppress_date',
                                                help    = 'Supress date prefix in output file (return only last dump)' )

    parser.add_argument( '-l', '--launch_sim', action  = 'store_true',
                                             dest    = 'launch_sim',
                                             help    = 'Launches the Lauterbach simulator displaying the system context for ' \
                                                       'the last dump. This works best if your current working directory is ' \
                                                       'at the same commit as the build stored on the network.' )

    parser.add_argument( '-u', '--use_local', action  = 'store_true',
                                            dest    = 'use_local',
                                            help    = 'Use locally defined build artifacts.' )
    args = parser.parse_args()

    if not os.path.exists( args.infile ):
        sys.stderr.write( '\nERROR: Input file does not exist' )
    else:
        last_dump = None
        with open( args.infile, 'r' ) as infile:
            regex_date      = re.compile( '(?P<month>\d{2})/(?P<day>\d{2})/(?P<year>\d{2})\s+(?P<hour>\d{2}):(?P<min>\d{2}):(?P<sec>\d{2})' )
            regex_dmp       = re.compile( '(dump:|dmp:) ' )
            regex_frame     = re.compile( 'Stack frame PC: (?P<pc>0x[A-Fa-f0-9]{8}).*SP: (?P<sp>0x[A-Fa-f0-9]{8})' )
            sw_ver_line     = re.compile( '\(Forerunner (?P<dev>\d+)\) SW ver: (?P<ver>\d*)' )
            regex_bld_type  = re.compile( 'Build Type: (?P<bld>\w*)' )

            error_key = ''
            bld_type = ''
            dev = ''
            ver = 0
            sp = 0
            pc = 0
            error_listing = {}
            for line in infile:
                sw_ver_rslt = sw_ver_line.search( line )
                if sw_ver_rslt:
                    dev = 'FR' + sw_ver_rslt.group( 'dev' )
                    ver = sw_ver_rslt.group( 'ver' )
                    # Format the string into maj.min
                    ver = '{}.{}'.format( ver[:-2:], ver[-2::] )
                    continue

                bld_type_rslt = regex_bld_type.search( line )
                if bld_type_rslt:
                    bld_type = bld_type_rslt.group( 'bld' )

                date_rslt = regex_date.search( line )
                if date_rslt:
                    error_key = '{}_{}_{}-{}-{}-{}'.format( date_rslt.group( 'month' ), date_rslt.group( 'day' ), date_rslt.group( 'year' ),
                                                     date_rslt.group( 'hour' ), date_rslt.group( 'min' ), date_rslt.group( 'sec' ) )
                    continue

                frame_rslt = regex_frame.search( line )
                if frame_rslt:
                    sp = int( frame_rslt.group( 'sp' ), 0 )
                    pc = int( frame_rslt.group( 'pc' ), 0 )
                    continue

                dmp_rslt = regex_dmp.search( line )
                if dmp_rslt:

                    dump_data = b64decode( line[dmp_rslt.end( 0 )::] )
                    if len( dump_data ) <= 32*1024:
                        sys_ram_addr = 0x1FFFE000
                    else:
                        sys_ram_addr = 0x1FFF0000

                    outfile = args.outfile
                    if not outfile:
                        outfile = "RAM_0x{:X}.bin".format( sys_ram_addr )

                    if args.suppress_date:
                        last_dump = Dump( dev, ver, bld_type_suffix[bld_type], outfile, dump_data, sys_ram_addr, sp, pc )
                    else:
                        last_dump = Dump( dev, ver, bld_type_suffix[bld_type], '{}_{}'.format( error_key, outfile ), dump_data, sys_ram_addr, sp, pc )
                    error_listing[error_key] = last_dump

            if args.suppress_date:
                write_dump( last_dump )
            else:
                for err in error_listing:
                    write_dump( error_listing[err] )

        if args.launch_sim and last_dump:
            if args.use_local:
                bld_loc = '.'
            else:
                bld_loc = os.path.join( network_bld_loc( last_dump.dev ), '{}{}'.format( last_dump.ver, last_dump.bld_type ) )

            if os.path.exists( T32_install_path ):
                sim = Popen( '_SIM_TRACE32.lnk', shell=True )
                t32api = cdll.LoadLibrary( T32_install_path )

                t32api.T32_Config('NODE=','localhost')
                # This must match the PORT defined in config.t32
                t32api.T32_Config('PORT=','20001')
                t32api.T32_Config('PACKLEN=','1024')

                while 0 != t32api.T32_Init():
                    pass
                t32api.T32_Attach(1)
                # Load Code
                t32api.T32_Cmd( 'Data.LOAD.Binary "{}" 0x0'.format( os.path.join( bld_loc, 'xldr_sys.bin' )) )
                # Load RAM
                t32api.T32_Cmd( 'Data.LOAD.Binary "{}" 0x{:x}'.format( last_dump.filename, last_dump.ram_addr ) )
                # Load Symbols
                t32api.T32_Cmd( 'sYmbol.SourcePATH.SetRecurseDir . ')
                t32api.T32_Cmd( 'Data.LOAD.Elf "{}" /NoCODE'.format( os.path.join( bld_loc, 'XLDR.axf' ) ) )
                t32api.T32_Cmd( 'Data.LOAD.Elf "{}" /NoCODE /NoClear'.format( os.path.join( bld_loc, 'SYS.axf' ) ) )
                # Setup Context
                t32api.T32_Cmd( 'Register.Set PC 0x{:x}'.format( last_dump.PC ) )
                t32api.T32_Cmd( 'Register.Set R13 0x{:x}'.format( last_dump.SP ) )
                # Terminate Connection
                t32api.T32_Exit()

                sim.wait()
            else:
                sys.stderr.write( "Couldn't find T32 install path at '{}'".format( T32_install_path ) )

if __name__ == "__main__":
    main()
