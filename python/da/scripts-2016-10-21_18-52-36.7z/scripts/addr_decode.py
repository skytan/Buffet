#Decode values that look like hex into their respective symbol + offset
#using the given map file
import mapfile
import re
import sys

hex_regex = re.compile( "(0[Xx][0-9A-Fa-f]{8})" )

infile = open( sys.argv[1], 'r' )
outfile = open( sys.argv[1] + ".decode.txt", 'w' )
mf = mapfile.MapFile.create( open( sys.argv[2], 'r' ) )

for line in infile:
    #returns tuple( text, [hex, text, hex, text, ...] )
    matches = hex_regex.split( line )
    if len( matches ) == 1:
        outfile.write(line)
        continue

    for i,m in enumerate( matches ):
        #always write out the original text
        outfile.write( m )
        if (i % 2) == 1:
            #If it was an address, then decode it
            addr = int( m, base=16 )
            symbol = mf.lookup_symbol_addr( addr )
            if symbol:
                #found a symbol for address, write out
                #symbol + offset
                offset = symbol.get_offset( addr )
                outfile.write( "[" + symbol.get_name() )
                if offset > 1:
                    outfile.write( "+" + str(offset) )
                outfile.write( ", " )
                outfile.write( symbol.source )
                outfile.write( "]" )
