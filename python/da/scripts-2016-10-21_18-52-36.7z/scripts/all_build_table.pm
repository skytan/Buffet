#!/c/Perl/bin/perl
#*********************************************************************
#
#   SCRIPT NAME:
#       all_build_table.pm -
#
#   DESCRIPTION:
#
#********************************************************************/

use strict;
use warnings;

# Stuff to make including from the current directory easy.
use Cwd 'abs_path';
use File::Basename;
use lib dirname( abs_path $0 );

package all_build_table;


#*********************************************************************
#
#   CONSTANTS
#
#*********************************************************************

#*********************************************************************
#
#   VARIABLES
#
#*********************************************************************

our @build_table;

#*********************************************************************
#
#   MAIN PROCESS
#
#*********************************************************************

@build_table =
    (
    ["Tandem",              "development",  "xldr"],
    ["Tandem",              "release",      "xldr"],
    ["Tandem",              "development",  "bb"],
    ["Tandem",              "release",      "bb"],
    ["Tandem",              "development",  "sys"],
    ["Tandem",              "release",      "sys"],
    ["Tandem_rvct",         "development",  "xldr"],
    ["Tandem_rvct",         "release",      "xldr"],
    ["Tandem_rvct",         "development",  "bb"],
    ["Tandem_rvct",         "release",      "bb"],
    ["Tandem_rvct",         "development",  "sys"],
    ["Tandem_rvct",         "release",      "sys"],
    ["Tandem_Sim",          "development",  "WS"],
    #
    ["Austin",              "development",  "xldr"],
    ["Austin",              "release",      "xldr"],
    ["Austin",              "development",  "bb"],
    ["Austin",              "release",      "bb"],
    ["Austin",              "development",  "sys"],
    ["Austin",              "release",      "sys"],
    ["Austin_rvct",         "development",  "xldr"],
    ["Austin_rvct",         "release",      "xldr"],
    ["Austin_rvct",         "development",  "bb"],
    ["Austin_rvct",         "release",      "bb"],
    ["Austin_rvct",         "development",  "sys"],
    ["Austin_rvct",         "release",      "sys"],
    ["Austin_Sim",          "development",  "WS"],
    #
    ["Mentat_gcc",          "development",  "xldr"],
    ["Mentat_gcc",          "release",      "xldr"],
    ["Mentat_gcc",          "development",  "bb"],
    ["Mentat_gcc",          "release",      "bb"],
#    ["Mentat_gcc",          "development",  "sys"],    # Out of space
    ["Mentat_gcc",          "release",      "sys"],
    ["Mentat",              "development",  "xldr"],
    ["Mentat",              "release",      "xldr"],
    ["Mentat",              "development",  "bb"],
    ["Mentat",              "release",      "bb"],
    ["Mentat",              "development",  "sys"],
    ["Mentat",              "release",      "sys"],
    ["Mentat_Sim",          "development",  "WS"],
    #
    ["Bebop",               "development",  "xldr"],
    ["Bebop",               "release",      "xldr"],
    ["Bebop",               "development",  "bb"],
    ["Bebop",               "release",      "bb"],
    ["Bebop",               "development",  "sys"],
    ["Bebop",               "release",      "sys"],
    ["Bebop_rvct",          "development",  "xldr"],
    ["Bebop_rvct",          "release",      "xldr"],
    ["Bebop_rvct",          "development",  "bb"],
    ["Bebop_rvct",          "release",      "bb"],
    ["Bebop_rvct",          "development",  "sys"],
    ["Bebop_rvct",          "release",      "sys"],
    ["Bebop_Sim",           "development",  "WS"],
    #
    ["Twin_Cities",         "development",  "xldr"],
    ["Twin_Cities",         "release",      "xldr"],
    ["Twin_Cities",         "development",  "bb"],
    ["Twin_Cities",         "release",      "bb"],
    ["Twin_Cities",         "development",  "sys"],
    ["Twin_Cities",         "release",      "sys"],
    ["Twin_Cities_rvct",    "development",  "xldr"],
    ["Twin_Cities_rvct",    "release",      "xldr"],
    ["Twin_Cities_rvct",    "development",  "bb"],
    ["Twin_Cities_rvct",    "release",      "bb"],
    ["Twin_Cities_rvct",    "development",  "sys"],
    ["Twin_Cities_rvct",    "release",      "sys"],
    ["Twin_Cities_Sim",     "development",  "WS"]
    );

# End of main module.
return 1;

#*********************************************************************
#
#   SUBROUTINES
#
#*********************************************************************

#*********************************************************************
#
#   PROCEDURE NAME:
#       NAME -
#
#   DESCRIPTION:
#
#*********************************************************************

exit;

