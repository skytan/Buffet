import os
import sys
import struct
import string
import bin_struct
import re
import shutil
import dump_analyze_112 as da_legacy

# Error data
RAM_MIN_SIZE = 0x8000
ERR_SIZE = 256

# Products
PRODUCT_MENTAT = 1956
PRODUCT_TANDEM = 2147
PRODUCT_TWIN_CITIES = 2148

PRODUCT_TO_SYS_ADDR = {
    PRODUCT_MENTAT : 0x800,
    PRODUCT_TANDEM : 0x1000,
    PRODUCT_TWIN_CITIES : 0x1000,
    }

PRODUCT_TO_RAM_ADDR = {
    PRODUCT_MENTAT : 0x1FFFE000,
    PRODUCT_TANDEM : 0x1FFF0000,
    PRODUCT_TWIN_CITIES : 0x1FFF0000,
    }

PRODUCT_TO_NAME = {
    PRODUCT_MENTAT : r'Vivosmart',
    PRODUCT_TANDEM : r'Edge20/25',
    PRODUCT_TWIN_CITIES : r'FR25',
    }

PRODUCT_TO_BUILD_DIRECTORY = {
    PRODUCT_MENTAT : r'\\bombay\data\PROJECTS\Consumer\Fitness\Wellness\Vivo_Smart\Software\current_boards',
    PRODUCT_TANDEM : r'\\bombay\data\PROJECTS\Consumer\Fitness\Edge\Edge_2X\SW\builds\system',
    PRODUCT_TWIN_CITIES : r'\\bombay\data\PROJECTS\Consumer\Fitness\Forerunner\Forerunner_25\Software\builds\system',
    }

# Error defines
ERR_VALID_KEY = 0x5f3759e0
UTL_HASH_SIZE = 40
UTL_ASSERT_MAX_STACK_PTR_DEPTH = 16
MAX_RAM_ERROR_SIZE = 100
UTL_ASSERT_MAX_FILE_NAME = 32
UTL_ASSERT_MAX_AUX = 32
UTL_NUM_RTL_REGS = 16

# UTL_err_id enum
UTL_ERR_ABNORMAL_PWRDN          =   0      # Abnormal Powerdown
# error and spurious vectors
UTL_FAULT_START                 =   1      #
UTL_ERR_NMI                     =   1      # Non-maskable Interrupt
UTL_ERR_HARD_FAULT              =   2      # Hard Fault
UTL_ERR_MEM_FAULT               =   3      # Memory Fault
UTL_ERR_BUS_FAULT               =   4      # Bus Fault
UTL_ERR_USAGE_FAULT             =   5      # Usage Fault
UTL_ERR_SVC                     =   6      # Supervisor Call Interrupt
UTL_ERR_DEBUG_MON               =   7      # Debug Monitor
UTL_ERR_SYS_TICK                =   8      # System Tick Interrupt
UTL_ERR_UNDEF_VCTR              =   9      # Spurious Interrupt
UTL_FAULT_END                   =   9      #
# assert
UTL_ERR_ASSERT                  =  10      # Software Assert
# rtl
UTL_ERR_RTL_TRAP                =  11      # RTL trap

# Build types
UTL_BLD_GCC_DEV = 1
UTL_BLD_GCC_REL = 2
UTL_BLD_RVCT_DEV = 3
UTL_BLD_RVCT_REL = 4

BLD_TYPE_TO_STRING = {}
BLD_TYPE_TO_STRING[UTL_BLD_GCC_DEV] = "GCC DEV"
BLD_TYPE_TO_STRING[UTL_BLD_GCC_REL] = "GCC REL"
BLD_TYPE_TO_STRING[UTL_BLD_RVCT_DEV] = "RVCT DEV"
BLD_TYPE_TO_STRING[UTL_BLD_RVCT_REL] = "RVCT REL"
def is_rel_bld( build_type ):
    return build_type == UTL_BLD_GCC_REL or build_type == UTL_BLD_RVCT_REL

# Structure declarations
members = "key@L product@H sw_ver@H build_type@B pad1@3B hash@{0}s dirty@? pad2@3B esn@L time@L time_ofst@l uptime@L \
reg_sp@L reg_psp@L reg_pc@L err_id@B pad3@3B data@{1}s call_stack@{2}L".format( UTL_HASH_SIZE, MAX_RAM_ERROR_SIZE, UTL_ASSERT_MAX_STACK_PTR_DEPTH )
utl_ram_error_type = bin_struct.struct_class( "utl_ram_error_type", members )

members = "reg@12L sp@L lr@L pc@L xpsr@L"
utl_exptn_log_type = bin_struct.struct_class( "utl_exptn_log_type", members )

members = "line_num@H pad@2B file_name_str@{0}s aux_str@{1}s".format( UTL_ASSERT_MAX_FILE_NAME, UTL_ASSERT_MAX_AUX )
utl_assert_log_type = bin_struct.struct_class( "utl_assert_log_type", members )

members = "errnum@L num_regs@B pad2@3s reg@{0}L".format( UTL_NUM_RTL_REGS )
utl_rtl_log_type = bin_struct.struct_class( "utl_rtl_log_type", members )
del members

scripts_dir = ""
current_build_directories_list = [ os.path.join( '..', 'out', 'current' ), '.' ]

def get_build_directories( product ):
    """Get directories containing sys.bin, sys.axf
    and da.exe"""
    dir_list = []
    for path in os.listdir( PRODUCT_TO_BUILD_DIRECTORY[product] ):
        dir_list.append( os.path.join( PRODUCT_TO_BUILD_DIRECTORY[product], path ) )
    dir_list += current_build_directories_list
    return dir_list

hash_to_dir_prod_dict = {}
def get_hashes_mappings( product = PRODUCT_MENTAT ):
    # TODO, opt - cached a version of the hash mappings on the network

    hash_to_dir = {}
    if product in hash_to_dir_prod_dict:
        # Hashes exist for the current product
        hash_to_dir = hash_to_dir_prod_dict[product]
    else:
        # Need to find hashes
        pattern = re.compile("[0-9a-f]{40}")
        for build_dir in get_build_directories( product ):
            sys_file_name = os.path.join( build_dir, "sys.bin" )
            if os.path.isfile( sys_file_name ):
                with open( sys_file_name, "rb" ) as f:
                    contents = f.read()
                result = pattern.findall( contents )
                if len(result) == 1:
                    hash_to_dir[result[0]] = build_dir
                elif len(result) > 1:
                    print( "Warning - duplicate hashes detected in %s" % sys_file_name )
        hash_to_dir_prod_dict[product] = hash_to_dir

    return hash_to_dir

def find_build_dir_from_hash( git_sha, rel_bld = False, product = PRODUCT_MENTAT ):
    hash_to_build_dir = get_hashes_mappings( product )
    if git_sha in hash_to_build_dir:
        dir = hash_to_build_dir[git_sha]
        if rel_bld and dir not in current_build_directories_list:
            dir = os.path.join( dir, "release" )
        return dir

def fmt_null_string( data ):
    start = string.find( data, '\0' )
    if start >= 0:
        return data[0:start]
    else:
        return data

# Run dump analyzer
def do_da( file, build_dir, output_dir, sp, pc, psp, ram_addr, rom_addr ):
    src_sys_bin = os.path.join( build_dir, "sys.bin" )
    src_sys_axf = os.path.join( build_dir, "sys.axf" )
    src_sys_map = os.path.join( build_dir, "sys.map" )
    src_ram = file
    src_da = os.path.join( build_dir, "da.exe" )

    dst_sys_bin = os.path.join( output_dir, "ROM_0x{:08x}.bin".format(rom_addr) )
    dst_sys_axf = os.path.join( output_dir, "sys.axf" )
    dst_sys_map = os.path.join( output_dir, "sys.map" )
    dst_ram = os.path.join( output_dir, "RAM_0x{:08x}.BIN".format(ram_addr) )
    dst_da = os.path.join( output_dir, "da.exe" )

    shutil.copy(src_sys_bin, dst_sys_bin)
    shutil.copy(src_sys_axf, dst_sys_axf)
    shutil.copy(src_sys_map, dst_sys_map)
    shutil.copy( src_da, dst_da)
    shutil.copy( src_ram, dst_ram)

    regs_filename = "regs.txt"
    da_bat = os.path.join( output_dir, "da.bat" )
    with open( da_bat, "wb" ) as f:
        f.write("da.exe sys.axf RAM_0x{:08x}.BIN ROM_0x{:08x}.bin -creg {}> da_output.txt 2>&1".format(ram_addr, rom_addr, regs_filename))

    da_regs = os.path.join( output_dir, regs_filename )
    with open( da_regs, "wb" ) as f:
        f.write("SP: 0x{:08x}\nPC: 0x{:08x}\nPSP: 0x{:08x}\n".format(sp, pc, psp))

    cwd = os.getcwd()
    os.chdir( output_dir )
    os.system( "da.bat > NUL" )
    os.chdir( cwd )

def create_sim_script( build_dir, output_dir, sp, pc, psp, ram_addr, rom_addr ):

    # Stay in sync with do_da
    dst_ram = os.path.join( output_dir, "RAM_0x{:08x}.BIN".format(ram_addr) )
    rom_base_file = "ROM_0x{:08x}.bin".format(rom_addr)
    ram_base_file = "RAM_0x{:08x}.BIN".format(ram_addr)
    sys_axf_base = "sys.axf"
    sim_file = os.path.join( output_dir, "start_sim.py" )

    format_str = """from argparse     import ArgumentParser
from base64       import standard_b64decode as b64decode
from collections  import namedtuple, OrderedDict
from ctypes       import cdll
import os
import os.path
import re
from subprocess   import Popen
import sys

dll = 't32api64.dll' if sys.maxsize > 2**32 else 't32api.dll'
T32_install_path = os.path.join( 'C:', os.sep, 'T32', 'demo', 'api', 'python', dll )
if os.path.exists( T32_install_path ):
    # Change to build directory
    prev_cwd = os.getcwd()
    new_cwd = os.path.dirname(prev_cwd)
    new_cwd = os.path.dirname(new_cwd)
    os.chdir(new_cwd)

    sim = Popen( '_TRACE32_SIM.lnk', shell=True )
    t32api = cdll.LoadLibrary( T32_install_path )

    t32api.T32_Config('NODE=','localhost')
    # This must match the PORT defined in config.t32
    t32api.T32_Config('PORT=','20001')
    t32api.T32_Config('PACKLEN=','1024')

    rom_file_loc = os.path.join(prev_cwd, "{0}")
    ram_file_loc = os.path.join(prev_cwd, "{2}")
    axf_file_loc = os.path.join(prev_cwd, "{4}")

    while 0 != t32api.T32_Init():
        pass
    t32api.T32_Attach(1)
    # Load Code
    t32api.T32_Cmd( 'Data.LOAD.Binary "%s" 0x{1:08x}' % rom_file_loc )
    print('Data.LOAD.Binary "%s" 0x{1:08x}' % rom_file_loc )
    # Load RAM
    t32api.T32_Cmd( 'Data.LOAD.Binary "%s" 0x{3:08x}' % ram_file_loc )
    print( 'Data.LOAD.Binary "%s" 0x{3:08x}' % ram_file_loc )
    # Load Symbols
    t32api.T32_Cmd( 'sYmbol.SourcePATH.SetRecurseDir . ')
    print( 'sYmbol.SourcePATH.SetRecurseDir . ')
    t32api.T32_Cmd( 'Data.LOAD.Elf ""%s /NoCODE /NoClear' % axf_file_loc )
    print( 'Data.LOAD.Elf "%s" /NoCODE /NoClear' % axf_file_loc )
    # Setup Context
    t32api.T32_Cmd( 'Register.Set PC 0x{5:08x}' )
    t32api.T32_Cmd( 'Register.Set PSP 0x{7:08x}' )
    t32api.T32_Cmd( 'Register.Set R13 0x{6:08x}' )
    # Terminate Connection
    t32api.T32_Exit()

    sim.wait()
else:
    sys.stderr.write( "Couldn't find T32 install path at '%s'" % T32_install_path )
        """
    format_str = format_str.format( rom_base_file, rom_addr, ram_base_file, ram_addr, sys_axf_base, pc, sp, psp )
    with open(sim_file, "wb") as f:
        f.write(format_str)

def parse_error( dump_file_name, output_dir, find_build_dir_from_hash_funct ):

    # Read file contents
    with open(dump_file_name, "rb") as f:
        file_contents = f.read()
    if len(file_contents) < RAM_MIN_SIZE:
        return False
    error_data = file_contents[-ERR_SIZE:]

    # Parse data into structs
    utl_ram_error = utl_ram_error_type()
    utl_ram_error.unpack( error_data )

    utl_exptn_log = utl_exptn_log_type()
    utl_exptn_log.unpack( utl_ram_error.data )

    utl_assert_log = utl_assert_log_type()
    utl_assert_log.unpack( utl_ram_error.data )

    utl_rtl_log = utl_rtl_log_type()
    utl_rtl_log.unpack( utl_ram_error.data )

    error_processed = False

    # Print out data
    if utl_ram_error.key != ERR_VALID_KEY:
        # Error key does not match, so see if this is a legacy format
        print "Error key mismatch: got 0x{:x} expected 0x{:x}".format( utl_ram_error.key, ERR_VALID_KEY )
        print "Trying legacy dump"
        error_processed = da_legacy.parse_error( dump_file_name, output_dir, find_build_dir_from_hash_funct )
    else:
        # Create output file
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)

        output_file_name = os.path.join( output_dir, "err_log.txt" )
        f = open(output_file_name, "wb")
        def write( data ):
            f.write( data )
            f.write( "\r\n" )

        if utl_ram_error.product in PRODUCT_TO_BUILD_DIRECTORY:
            write( "{0} ({1}) SW ver: {2}".format( utl_ram_error.product, PRODUCT_TO_NAME[utl_ram_error.product], utl_ram_error.sw_ver ) )
        else:
            write( "{0} SW ver: {1}".format( utl_ram_error.product, utl_ram_error.sw_ver ) )

        if utl_ram_error.build_type in BLD_TYPE_TO_STRING:
            write( "Build Type: {0}".format( BLD_TYPE_TO_STRING[utl_ram_error.build_type] ) )
        else:
            write( "Unknown build type" )

        write( "ESN: {0}".format( utl_ram_error.esn ) )
        #TODO - add time
        rel_bld = is_rel_bld( utl_ram_error.build_type )
        build_dir =  find_build_dir_from_hash_funct( utl_ram_error.hash, rel_bld, utl_ram_error.product )
        if utl_ram_error.dirty:
            write( "Commit: {0}*".format( utl_ram_error.hash ) )
        else:
            write( "Commit: {0}".format( utl_ram_error.hash ) )

        if build_dir:
            write( "Build dir: {0}".format( build_dir ) )
        else:
            write( "Could not find system image" )
        write( "Time: {0}".format( utl_ram_error.time ) )

        if utl_ram_error.err_id == UTL_ERR_ASSERT:
            write( "Assert" )
            write( "{0} line {1}".format( fmt_null_string(utl_assert_log.file_name_str), utl_assert_log.line_num ) )
        elif utl_ram_error.err_id == UTL_ERR_RTL_TRAP:
            write( "RTL Trap" )
            write( "errnum: 0x{0:08x}".format( utl_rtl_log.errnum ) )
            for i in range( utl_rtl_log.num_regs ):
                write( "r{0}: 0x{1:08x}".format( i, utl_rtl_log.reg[i] ) )
        elif utl_ram_error.err_id >= UTL_FAULT_START and utl_ram_error.err_id <= UTL_FAULT_END:
            write( "Hard Fault" )
            write( "PC: 0x{0:08x}".format( utl_exptn_log.pc ) )
            write( "LR: 0x{0:08x}".format( utl_exptn_log.lr ) )
            write( "SP: 0x{0:08x}".format( utl_exptn_log.sp ) )
        elif utl_ram_error.err_id == UTL_ERR_ABNORMAL_PWRDN:
            write( "Abnormal powerdown" )
        else:
            write( "Unknown error {0}".format( utl_ram_error.err_id ) )

        # These values are not recorded for abnormal powerdowns
        if utl_ram_error.err_id != UTL_ERR_ABNORMAL_PWRDN:
            stack_dumped = utl_ram_error.reg_sp
            if utl_ram_error.err_id >= UTL_FAULT_START and utl_ram_error.err_id <= UTL_FAULT_END:
                stack_dumped = utl_ram_error.reg_psp
            write( "Stack frame PC, SP: 0x{0:08x}, 0x{1:08x}".format( utl_ram_error.reg_pc, utl_ram_error.reg_sp ) )
            write( "Stack frame PSP: 0x{0:08x}".format( utl_ram_error.reg_psp ) )
            write( "Call Stack - SP at 0x{0:08x}".format( utl_ram_error.reg_sp ) )
            for addr in utl_ram_error.call_stack:
                write( "\t0x{0:08x}".format( addr ) )
            write( "Uptime: {0}".format( utl_ram_error.uptime ) )

        if f is not None:
            f.close()

        if build_dir:
            ram_addr = PRODUCT_TO_RAM_ADDR[utl_ram_error.product]
            sys_addr = PRODUCT_TO_SYS_ADDR[utl_ram_error.product]
            do_da( dump_file_name, build_dir ,output_dir, utl_ram_error.reg_sp, utl_ram_error.reg_pc, utl_ram_error.reg_psp, ram_addr, sys_addr )
            create_sim_script( build_dir ,output_dir, utl_ram_error.reg_sp, utl_ram_error.reg_pc, utl_ram_error.reg_psp, ram_addr, sys_addr )
            #decode addresses in err log if we found the build
            if scripts_dir:
                addr_py = os.path.join( scripts_dir, "addr_decode.py" )
                mf = os.path.join( output_dir, "sys.map" )
                cmd = "python {} {} {}".format( addr_py, output_file_name, mf )
                os.system( cmd )

        error_processed = True

    return error_processed

if __name__ == "__main__":
    if len(sys.argv) <= 1:
        print( "Processing files in current directory:" )
        print("")
        filenames = os.listdir(".")
    else:
        filenames = [ sys.argv[1] ]

    parts = os.getcwd().split( "scripts" )
    parts = parts[:-1]
    if parts:
        parts.append( "scripts" )
        scripts_dir = os.path.join( *parts )
    for filename in filenames:
        ( name, ext ) = os.path.splitext( filename )
        ext = ext.lower()
        if ext == ".bin":
            output_dir = name
            if parse_error( filename, output_dir, find_build_dir_from_hash ):
                print( "{0:20} -> {1}".format( filename, output_dir ) )
