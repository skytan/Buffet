import bin_struct
import sys

BINARY_MAGIC = 0xFADBADA5

header_cls = bin_struct.struct_class( "header_cls", "magic@I sw_ver@H idac_vals@10B" )
first_line_cls  = bin_struct.struct_class( "first_line_cls", "log_count@B button_seq@B raws@5H diffs@5H baselines@5H" )
other_lines_cls = bin_struct.struct_class( "other_lines_cls", "log_count@B button_seq@B raws@5H" )

f = open( sys.argv[1], 'rb' )
data = f.read()
f.close()

offset = 0

header = header_cls()
first_line = first_line_cls()
other_line = other_lines_cls()

print other_line.header()

header.unpack( data )
print header.delimited()
offset += header.SIZEOF

first_line.unpack( data[offset:offset+first_line.SIZEOF ] )
print first_line.delimited()
offset += first_line.SIZEOF

while offset < len( data ):
    other_line.unpack( data[offset:offset+other_line.SIZEOF] )
    print other_line.delimited()
    offset += other_line.SIZEOF
