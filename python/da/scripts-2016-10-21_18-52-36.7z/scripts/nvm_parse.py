#!/usr/bin/env python

import binascii
import bin_struct
from collections import defaultdict
import os
import sys
from optparse import OptionParser

NVM_TAG_SCTR_HDR                = 1
NVM_TAG_UID                     = 2

RECORD_HEADER_FORMAT = "tag@B csum@B flags_size@H"
RecordHeader = bin_struct.struct_class( "RecordHeader", RECORD_HEADER_FORMAT )

RECORD_SIZE_MASK         =       ( 0x1FFF )
RECORD_DONE_FLAG_MASK    =       ( 0x2000 )
RECORD_DEL_FLAG_MASK     =       ( 0x4000 )
RECORD_DUP_FLAG_MASK     =       ( 0x8000 )

class Record:
    def __init__( self, hdr, data, offset ):
        self.hdr = hdr
        self.data = data
        self.offset = offset

    def __str__( self ):
        s = "0x%08X, " % ( self.offset, )
        s += '0x%04x, %5d, 0x%04x, %4d,' % ( self.hdr.tag, self.hdr.tag, self.hdr.data_size, self.hdr.data_size )
        s += '0x%02x,' % ( self.hdr.csum, )
        if self.hdr.flag_del:
            s += 'del,'
        else:
            s += '   ,'

        if self.hdr.flag_dup:
            s += 'dup,'
        else:
            s += '   ,'

        if self.hdr.flag_done:
            s += 'done,'
        else:
            s += '    ,'

        s += binascii.hexlify( self.data )
        return s

class NvmStats:
    """
    Statistics about the NVM.
    """
    def __init__( self, ttlSpc = 0, ttlDelSpc = 0, ttlUsdSpc = 0,\
                        ttlUsdTgs = 0, ttlDelTgs = 0, tagCountDict = None ):
        self.totalSpace = 0
        self.totalDeletedSpace = 0
        self.totalUsedSpace = 0
        self.totalUsedTags = 0
        self.totalDeletedTags = 0
        if tagCountDict is None:
            tagCountDict = {}
        self.tagCountDict = tagCountDict

    def __str__( self ):
        s = '\n\nTotal Space %d (0x%08x)\n' % ( self.totalSpace, self.totalSpace )
        s += 'Used Space (not deleted) %d (0x%08x) = %f percent\n' % \
                     ( self.totalUsedSpace, self.totalUsedSpace, \
                     ( float( self.totalUsedSpace ) / float( self.totalSpace ) ) * 100.0 )
        s += 'Deleted Space %d (0x%08x) = %f percent\n' % \
                     ( self.totalDeletedSpace, self.totalDeletedSpace, \
                     ( float( self.totalDeletedSpace ) / float( self.totalSpace ) ) * 100.0 )

        s += 'Used Tags (not deleted) %d (0x%08x)\n' % ( self.totalUsedTags, self.totalUsedTags )
        s += 'Deleted Tags %d (0x%08x)\n' % ( self.totalDeletedTags, self.totalDeletedTags )
        return s

def cmpSectorHeader( a, b ):
    """
    Comparison function used for sorting a list of sectorHeader classes.
    """
    if a.sectorId < b.sectorId:
        return -1
    if a.sectorId > b.sectorId:
        return 1
    return 0


def getRecordList( data, stats ):
    """
    Get a list of records given the sector data.
    """
    recordList = []
    offset = 0
    last_hdr = None

    while offset < len( data ):
        hdr = RecordHeader()
        hdr.unpack( data[offset:offset+RecordHeader.SIZEOF] )

        #if it is all erased then we may be done with the sector
        if hdr.tag == 0xFF and hdr.csum == 0xFF and hdr.flags_size == 0xFFFF:
            if last_hdr and last_hdr.tag == NVM_TAG_SCTR_HDR:
                print "Erased unit id at offset", offset
                offset += 8
                last_hdr = None
                continue
            else:
                print "ALL ERASED at offset", offset
            break

        #Break apart flags and size. True means flag is active,
        #that is, cleared to 0 in flash.
        hdr.data_size = hdr.flags_size & RECORD_SIZE_MASK

        hdr.flag_done = hdr.flags_size & RECORD_DONE_FLAG_MASK
        if hdr.flag_done:
            hdr.flag_done = False
        else:
            hdr.flag_done = True

        hdr.flag_del = hdr.flags_size & RECORD_DEL_FLAG_MASK
        if hdr.flag_del:
            hdr.flag_del = False
        else:
            hdr.flag_del = True

        hdr.flag_dup = hdr.flags_size & RECORD_DUP_FLAG_MASK
        if hdr.flag_dup:
            hdr.flag_dup = False
        else:
            hdr.flag_dup = True

        size_used = ( hdr.SIZEOF + hdr.data_size )

        #update tag stats
        if hdr.tag not in stats.tagCountDict:
            stats.tagCountDict[ hdr.tag ] = 1
        else:
            stats.tagCountDict[ hdr.tag ] += 1

        if not hdr.flag_del:
            stats.totalUsedSpace += size_used
            stats.totalUsedTags += 1
        else:
            stats.totalDeletedSpace += size_used
            stats.totalDeletedTags += 1

        #split out record data and add record to list
        start = offset + hdr.SIZEOF
        record_data = data[ start : start + hdr.data_size ]

        rec = Record( hdr, record_data, offset )
        recordList.append( rec )

        #move to next record
        offset += size_used
        last_hdr = hdr

    return recordList

def get_tag_names( nvm_pub_filename ):
    import re
    regex = re.compile( ".*NVM_TAG_(?P<NAME>.*) += +(?P<ID>[0-9]+)," )
    f = open( nvm_pub_filename, 'r' )
    tag_dict = defaultdict( str )
    for line in f:
        match = regex.match( line )
        if not match:
            continue
        tag_name = match.group( "NAME" )
        tag_id = int( match.group( "ID" ) )
        tag_dict[ tag_id ] = tag_name
    f.close()
    return tag_dict

if __name__ == '__main__':
    sector_size = 4 * 1024  #arg?

    # Set up valid arguments
    parser = OptionParser()
    parser.add_option( '-i', '--infile', dest = 'inputFileName',\
                       help = 'NVM region data.', metavar = 'INPUT' )
    parser.add_option( '-v', '--verbose', action = 'store_true', dest = 'verbose',\
                       help = 'More verbose output.' )
    parser.add_option( '-r', '--report', dest = 'reportFileName',\
                       help = 'Create report.', metavar = 'REPORT_FILE' )
    parser.add_option( '-n', '--nvm_header', dest = 'nvm_pub_filename', \
                       help = 'Get tag names from NVM header file' )

    # Parse arguments
    ( options, args ) = parser.parse_args()

    # Shall we be verbose?
    if options.verbose is None or options.verbose is False:
        verbose = False
    else:
        verbose = True

    # We at least need an input file.
    if not options.inputFileName:
        print 'You must specify an input file (use --help for help)!'
        sys.exit( 1 )

    # Make sure it's a file
    if not os.path.isfile( options.inputFileName ):
        print '%s is not a file!' % ( options.inputFileName )
        sys.exit( 1 )

    #Read tag names if file provided
    tag_dict = defaultdict( str )
    if options.nvm_pub_filename:
        tag_dict = get_tag_names( options.nvm_pub_filename )

    print '\n\nInput file is: %s' % ( options.inputFileName )

    # Read the entire input
    inFile = open( options.inputFileName, 'rb' )
    data = inFile.read()
    inFile.close()

    # Create report if requested
    if options.reportFileName:
        # Write the header
        rFile = open( options.reportFileName, 'w' )

        sidx = 0
        stats = NvmStats()
        while data:
            sector_data = data[:sector_size]
            if len( sector_data ) != sector_size:
                print "DONE! partial sector data remains, bytes:", len( sector_data )
                break

            stats.totalSpace += sector_size
            data = data[sector_size:]
            recordList = getRecordList( sector_data, stats )

            rFile.write( 'sector_%u_tag_name,offset,tag,tag,size,size,csum,del_flag,dup_flag,done_flag,data\n' % (sidx, ) )
            # Write the records
            for record in recordList:
                #rFile.write( record.hdr.pprint() )
                rFile.write( tag_dict[ record.hdr.tag ] + "," )
                rFile.write( '%s\n' % ( str( record ) ) )

            sidx += 1
            rFile.write( "\n" )

        # Print histogram
        rFile.write( '\nTag histogram\n' )
        rFile.write( 'tag_name,tag_id,count\n' )
        keyz = stats.tagCountDict.keys()
        keyz.sort()
        for tag in keyz: #tag in stats.tagCountDict:
            rFile.write( '%s, 0x%04x, %d\n' % ( tag_dict[tag], tag, stats.tagCountDict[ tag ] ) )

        # Write the stats
        rFile.write( str( stats ) )

        rFile.close()
