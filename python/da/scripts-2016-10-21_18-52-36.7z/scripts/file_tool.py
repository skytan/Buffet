# coding=UTF-8
import argparse
import os
import os.path
import re
import shutil
import sys
import threading
import time

debug = False
running = True

def drive_watcher( drive, args ):
    """
    Watch a particular drive letter and if a drive is found look at
    the files and see if we need to do anything for the device
    attached to the drive
    """
    global running
    id_regex = re.compile( ".*<Id>(?P<UNIT_ID>[0-9]{1,10})</Id>.*" )

    #Device side dirs and files
    garmin_dir = os.path.join( drive, 'GARMIN' )
    newfiles_dir = os.path.join( garmin_dir, 'NEWFILES' )
    remotesw_dir = os.path.join( garmin_dir, "REMOTESW" )
    dirs = ( garmin_dir, newfiles_dir, remotesw_dir )

    pdcsv = os.path.join( drive, "PENDATA.CSV" )
    tmtxt = os.path.join( drive, "TESTMODE.TXT" )
    gdxml = os.path.join( garmin_dir, "GarminDevice.xml" )
    gupdate = os.path.join( garmin_dir, "gupdate.rgn" )
    config_update = os.path.join( newfiles_dir, "config.fit" )
    psoc_update = os.path.join( remotesw_dir, "GUP2005.bin" )
    nordic_update = os.path.join( remotesw_dir, "GUP1955.bin" )

    while running:
        time.sleep( 1 )

        #See if GarminDevice.xml exists
        if not os.path.exists( gdxml ):
            if debug:
                print "No GarminDevice.xml for drive", drive
            continue

        #Make sure the device is a vivosmart
        f = open( gdxml, "r" )
        data = f.read()
        f.close()

        if data.find( "v\xc3\xadvosmart" ) < 0:
            if debug:
                print "GarminDevice.xml is not vivosmart"
            continue

        #Get the id from the xml data <Id>3891110194</Id>
        id_match = id_regex.match( data )
        if not id_match:
            continue

        unit_id = int( id_match.group( "UNIT_ID" ) )
        if debug:
            print "Found unit id", unit_id

        #make any dirs required
        for d in dirs:
            if not os.path.exists( d ):
                try:
                    os.mkdir( d )
                except:
                    pass

        #Copy any pendata log (if any) to the destination then remove the file
        if args.pendata_dir:
            if os.path.exists( pdcsv ):
                f = open( pdcsv, "r" )
                data = f.read()
                f.close()
                outpath = os.path.join( args.pendata_dir, str( unit_id )+".csv" )
                f = open( outpath, 'w' )
                f.write( data )
                f.close()

                os.unlink( pdcsv )

                #print output with line between every ten outputs
                print "Extracted PENDATA.CSV for drive", drive, "unit id", unit_id

        #Put the test file
        if args.testmode and not os.path.exists( tmtxt ):
            f = open( tmtxt, 'w' )
            f.close()
            print "Put testfile for drive", drive, "unit id", unit_id

        #put the software updates and config files
        if args.sys_update and not os.path.exists( gupdate ):
            shutil.copyfile( args.sys_update, gupdate )
            print "Put system update for drive", drive, "unit id", unit_id

        if args.psoc_update and not os.path.exists( psoc_update ):
            shutil.copyfile( args.psoc_update, psoc_update )
            print "Put psoc update for drive", drive, "unit id", unit_id

        if args.nordic_update and not os.path.exists( nordic_update ):
            shutil.copyfile( args.nordic_update, nordic_update )
            print "Put nordic update for drive", drive, "unit id", unit_id

        if args.config_update and not os.path.exists( config_update ):
            shutil.copyfile( args.config_update, config_update )
            print "Put config file for drive", drive, "unit id", unit_id

if __name__ == "__main__":
    #Parse command line
    parser = argparse.ArgumentParser( description="Vivosmart file put/get utility", epilog="" )

    #Put files on device options
    parser.add_argument("-s", "--sys_update", type=str, help="System software update file", default='' )
    parser.add_argument("-p", "--psoc_update", type=str, help="PSOC software update file", default='' )
    parser.add_argument("-n", "--nordic_update", type=str, help="Nordic software update file", default='' )
    parser.add_argument("-c", "--config_update", type=str, help="Configuration update file", default='' )

    #Pull files from device options
    parser.add_argument("-P", "--pendata_dir", type=str, help="PENDATA extraction directory", default='' )
    #parser.add_argument("-D", "--dumpfile_dir", type=str, help="Dump file extraction directory", default='' )
    parser.add_argument("-T", "--testmode", action="store_true", help="Put test mode file" )

    args = parser.parse_args()

    for d in ( args.pendata_dir, ):#TODO args.dumpfile_dir ):
        if d:
            try:
                os.makedirs( d )
            except:
                pass

    print "Scanning drives for vivosmart..."
    threads = []
    for drive_letter in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
        drive = drive_letter + ":"
        threads.append( threading.Thread( target=drive_watcher, args=( drive, args ) ) )
    for t in threads:
        t.start()

    while 1:
        if 'quit' == raw_input():
            running = False
            for t in threads:
                t.join()
            sys.exit(0)

