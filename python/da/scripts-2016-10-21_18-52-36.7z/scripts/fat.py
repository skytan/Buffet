import os
import os.path
import datetime
#from   optparse import OptionParser
import struct
import sys
import binascii as ba

"""
#create a bin file the size of the device
f = open( "fs.bin", 'wb' )
data = "\x00" * 1024 * 1024
for i in range( 2 * 1024 ):
    f.write( data )
f.close()

#format
mkdosfs -f 2 -F 32 -i aabbccdd -n THEFATVOLNM -s 8 -S 512 -v fs.bin

#mount
mount ./fs.bin ./mnt -t vfat -o loop=/dev/loop0,blocksize=512
"""

def getstr( raw, start, size ):
    fmt = str( size ) + "s"
    ( s, ) = struct.unpack( fmt, raw[ start:start+size ] )
    return s

def getint( raw, fmt, start ):
    #force little endian
    fmt = "<" + fmt
    #calc size of integer
    size = struct.calcsize( fmt )
    #unpack value
    ( i, ) = struct.unpack( fmt, raw[ start:start+size ] )
    return i

def getutf16( raw, start, size ):
    s = u""
    if size & 1:
        print "Bad UTF16 byte size "
        return s
    s = raw[ start:start+size ]
    return unicode( s, 'utf_16' )


def parse_int( input ):
    input = input.lower()
    b = 10
    if input.startswith( "0x" ):
        b = 16
    elif input.startswith("0"):
        b = 8
    try:
        print "input", input, "base", b
        v = int( input, base=b )
        return ( True, v )
    except:
        return ( False, 0 )

def print_bin( data, width=16, offset=0, offset2=None, redir=sys.stdout ):
    start = 0
    while start < len( data ):
        s = data[ start:start+width ]
        w = min( len( s ), width )
        fmt = w * "B"
        hexfmt = "%02X " * w
        antiw = width - w
        hexdummy = antiw * "   "
        bytes = struct.unpack( fmt, s )
        offstr = "0x%08x " % ( offset + start, )
        hexstr = hexfmt % bytes
        ascstr = ""
        for x in bytes:
            if x >= 0x20 and x < 0x7F:
                c = chr( x )
                ascstr += c
            else:
                ascstr += "."
        print >> redir, offstr,
        if offset2 is not None:
            offstr = "0x%08x " % ( offset2 + start, )
            print >> redir, offstr,
        print >> redir, hexstr + hexdummy, "'" + ascstr + "'"
        start += width

class DE:
    """
    Directory entry
    """
    ATTR_READ_ONLY = 0x1
    ATTR_HIDDEN = 0x2
    ATTR_SYSTEM = 0x4
    ATTR_VOLUME_ID = 0x8
    ATTR_DIRECTORY = 0x10
    ATTR_ARCHIVE = 0x20
    ATTR_LONG_NAME = ATTR_READ_ONLY | ATTR_HIDDEN | ATTR_SYSTEM | ATTR_VOLUME_ID
    ATTR_LONG_NAME_MASK = ATTR_LONG_NAME | ATTR_DIRECTORY | ATTR_ARCHIVE

    DE_SIZE = 32

    DE_FREE_NAME = 0xE5
    DE_FREE_LAST = 0x00

    def __init__( self, raw ):
        if len( raw ) != DE.DE_SIZE:
            print "foobacious dirent data size"

        self.attr = getint( raw, "B", 11 )
        self.lo_clust = getint( raw, "H", 26 )

    def _attr_str( self ):
        s = []
        poss = [ "READ_ONLY", "HIDDEN", "SYSTEM", "VOLUME_ID", "DIRECTORY", "ARCHIVE" ]
        if self.is_long_filename():
            s.append( "LONG FILENAME" )
        else:
            for a in poss:
                if getattr( self, "ATTR_" + a ) & self.attr:
                    s.append( a )
        return ",".join( s )

    def is_dir( self ):
        return (self.attr & DE.ATTR_DIRECTORY) != 0

    def is_free( self ):
        return True

    def is_long_filename( self ):
        return (self.attr & DE.ATTR_LONG_NAME_MASK) == DE.ATTR_LONG_NAME

    def is_vol( self ):
        return (self.attr & DE.ATTR_VOLUME_ID) != 0

    def get_csum( self ):
        """
        Subclass should implement
        """
        pass

    def get_name( self ):
        """
        Subclass should implement
        """
        pass

    def __repr__( self ):
        return str( self )

    def __str__( self ):
        s = "attr  " + hex( self.attr ) + " " + self._attr_str() + "\n"
        return s

    @staticmethod
    def create( raw ):
        d = DE( raw )
        if d.is_long_filename():
            return LongDE( raw )
        return ShortDE( raw )

class LongDE( DE ):
    """
    Long name directory entry
    """
    TYPE_LONGDIR = 0

    def __init__( self, raw ):
        DE.__init__( self, raw )
        self.ordinal = getint( raw, "B", 0 ) #sequence number + end flag
        self.name1 = getutf16( raw, 1, 10 )
        #self.attr = getint( raw, "B", 11 )
        self.type = getint( raw, "B", 12 )
        self.csum = getint( raw, "B", 13 )
        self.name2 = getutf16( raw, 14, 12 )
        #self.lo_clust = getint( raw, "H", 26 )
        self.name3 = getutf16( raw, 28, 4 )

        if self.lo_clust != 0:
            print "BOGUS! Long name low cluster not zero", repr( self.lo_clust )

        self.name = self.name1 + self.name2 + self.name3
        f = self.name.find( unichr( 0 ) )
        if f == 0:
            print "Bogus start of long filename"
        elif f > 0:
            self.name = self.name[ :f ]
        else:
            pass
            #all chars are valid...

        if self.type != LongDE.TYPE_LONGDIR:
            print "Unknown longdir type", repr( self.type )

    def get_csum( self ):
        return self.csum

    def get_name( self ):
        if self.is_free():
            return u"<FREE>" + self.name
        else:
            return self.name

    def is_free( self ):
        magic = self.ordinal
        if magic == DE.DE_FREE_LAST:
            return True
        elif magic == DE.DE_FREE_NAME:
            return True
        return False

    def is_free_last( self ):
        magic = self.ordinal
        if magic == DE.DE_FREE_LAST:
            return True
        return False

    def __repr__( self ):
        return str( self )

    def __str__( self ):
        s = self.name + "\n"
        s += "ord   " + hex( self.ordinal ) + "\n"
        s += "csum  " + hex( self.get_csum() ) + "\n"
        s += "attr  " + hex( self.attr ) + " " + self._attr_str() + "\n"
        s += "type  " + hex( self.type ) + "\n"
        return s

class ShortDE( DE ):
    """
    Short name directory entry
    """
    DIR_SUB_0xE5  = 0x05

    trans = [ chr( c ) for c in range( 256 ) ]
    trans[ DIR_SUB_0xE5 ] = chr( 0xe5 )
    JP_TRANS = "".join( trans )
    ILLEGAL_CHARS = [ 0x22, 0x2A, 0x2B, 0x2C, 0x2E, 0x2F, 0x3A, 0x3B, 0x3C, 0x3D, 0x3E, 0x3F, 0x5B, 0x5C, 0x5D, 0x7C ]

    nac = [ '?' for i in range( 0x20 - 0x0 ) ] + [ chr( c ) for c in range( 0x20, (0x80-1) ) ] + [ '?' for i in range( 0x100 - (0x80-1) ) ]
    NON_ASCII_CHARS = "".join( nac )

    def __init__( self, raw ):
        DE.__init__( self, raw )

        self.raw_name = getstr( raw, 0, 11 )
        #self.attr = getint( raw, "B", 11 )
        self.nt_reserved = getint( raw, "B", 12 )
        self.crt_time_hunds = getint( raw, "B", 13 )
        self.crt_time = getint( raw, "H", 14 )
        self.crt_date = getint( raw, "H", 16 )
        self.acc_date = getint( raw, "H", 18 )
        self.hi_clust = getint( raw, "H", 20 )
        self.wrt_time = getint( raw, "H", 22 )
        self.wrt_date = getint( raw, "H", 24 )
        #self.lo_clust = getint( raw, "H", 26 )
        self.file_size = getint( raw, "I", 28 )
        if self.is_dir() and self.file_size != 0:
            print "bogus file_size in directory", self.get_short_name()
        self.csum = self._checksum()

    def _parse_date( self, date ):
        dom  = ( date & 0x001F ) >> 0
        moy  = ( date & 0x01E0 ) >> 5
        year = ( date & 0xFE00 ) >> 9
        year += 1980

        bogus = False
        if dom == 0 or dom > 31:
            print "bogus day of month", repr( dom )
            bogus = True

        if moy == 0 or moy > 12:
            print "bogus month of year", repr( moy )
            bogus = True

        if bogus:
            year = 1989
            moy = 1
            dom = 1

        return ( year, moy, dom )

    def _parse_time( self, time, hunds=0 ):
        sec  = ( time & 0x001F ) >> 0
        min  = ( time & 0x07E0 ) >> 5
        hour = ( time & 0xF800 ) >> 11
        sec = sec * 2

        bogus = False
        if sec > 58:
            print "bogus seconds", repr( sec )
            bogus = True

        if min > 59:
            print "bogus minutes", repr( min  )
            bogus = True

        if hour > 23:
            print "bogus hours", repr( hour )
            bogus = True

        if hunds >= 200:
            print "bogus hunds"
            bogus = True

        if bogus:
            sec = 0
            min = 0
            hour = 0
            hunds = 0

        sec += hunds / 100
        usec = ( hunds % 100 ) * 10 * 1000

        return ( hour, min, sec, usec )

    def get_csum( self ):
        return self.csum

    def _checksum( self ):
        sum = 0
        for c in self.raw_name:
            if sum & 1:
                s = 0x80
            else:
                s = 0
            sum = s + ( sum >> 1 ) + ord( c )
            sum = sum & 0xff
        return sum

    def _is_user_dir( self, name ):
        if name in ( ".".ljust(8+3), "..".ljust(8+3) ):
            return False
        return True

    def is_free( self ):
        magic = ord( self.raw_name[0] )
        if magic == DE.DE_FREE_LAST:
            return True
        elif magic == DE.DE_FREE_NAME:
            return True
        return False

    def is_free_last( self ):
        magic = ord( self.raw_name[0] )
        if magic == DE.DE_FREE_LAST:
            return True
        return False

    def is_user_dir( self ):
        name = self.get_short_name()
        ret = self._is_user_dir( self.raw_name )
        return ret

    def get_clust( self ):
        return self.lo_clust + ( self.hi_clust << 16 )

    def get_name( self ):
        return unicode( self.get_short_name() )

    def get_short_name( self ):
        #---------------------------------------------------
        # fix japanese char 0xe5
        #---------------------------------------------------
        name = self.raw_name.translate( ShortDE.JP_TRANS )

        if self.is_free():
            nv = ord( name[1] )
            if nv >= 0x20 and nv < 0x80:
                return "<FREE>" + name[1:]
            else:
                return "<FREE>"

        #---------------------------------------------------
        # validate name characters
        #---------------------------------------------------
        if ord( name[0] ) < 0x20:
            print "Bogus name start character", repr( name )

        #---------------------------------------------------
        # If not a special dir name, validate name chars
        #---------------------------------------------------
        if not self._is_user_dir( name ):
            pass
        else:
            for c in name:
                if ord( c ) in ShortDE.ILLEGAL_CHARS:
                    print "Bogus char", repr( c ), "in dirent", repr( name )

        #---------------------------------------------------
        # get short name
        #---------------------------------------------------
        start = getstr( name, 0, 8 )
        start = start.strip()

        ext = getstr( name, 8, 3 )
        ext = ext.strip()

        if self.is_dir() or self.is_vol():
            name = start + ext
        else:
            name = start + "." + ext

        #---------------------------------------------------
        # In case of corruption, convert non-ascii chars
        #---------------------------------------------------
        name = name.translate( ShortDE.NON_ASCII_CHARS )

        return name

    def get_size( self ):
        return self.file_size

    def get_acc_datetime( self ):
        ( year, month, day ) = self._parse_date( self.acc_date )
        d = datetime.datetime( year, month, day )
        return d

    def get_crt_datetime( self ):
        ( year, month, day ) = self._parse_date( self.crt_date )
        ( hour, min, sec, usec ) = self._parse_time( self.crt_time, self.crt_time_hunds )
        d = datetime.datetime( year, month, day, hour, min, sec, usec )
        return d

    def get_wrt_datetime( self ):
        ( year, month, day ) = self._parse_date( self.wrt_date )
        ( hour, min, sec, usec ) = self._parse_time( self.wrt_time )
        d = datetime.datetime( year, month, day, hour, min, sec, usec )
        return d

    def __repr__( self ):
        return str( self )

    def __str__( self ):
        s = ""
        if self.is_free():
            s += "<FREE>\n"
        s += self.get_short_name() + "\n"
        s += "ACC   " + self.get_acc_datetime().ctime() + "\n"
        s += "CRT   " + self.get_crt_datetime().ctime() + "\n"
        s += "WRT   " + self.get_wrt_datetime().ctime() + "\n"
        s += "csum  " + hex( self.get_csum() ) + "\n"
        s += "attr  " + hex( self.attr ) + " " + self._attr_str() + "\n"
        s += "clust " + str( self.get_clust() ) + ", " +hex( self.get_clust() ) + "\n"
        s += "size  " + str( self.get_size() ) + "\n"

        return s

class DirItem:
    """
    Directory Item is the aggregation of a ShortDE and its
    LongDEs if any exist.
    """
    def __init__( self, sde ):
        self.sde = sde
        self.ldes = []

    def add_lde( self, lde ):
        if not lde.is_free() and lde.get_csum() != self.sde.get_csum():
            print "Long directory checksum doesn't match short directory"
            print "Long:", lde.get_name()
            print "Shrt:", self.sde.get_name()
        self.ldes.append( lde )

    def get_long_name( self ):
        if self.ldes:
            return u"".join( [ n.get_name() for n in self.ldes ] )
        return u""

    def get_short_name( self ):
        return self.sde.get_name()

    def get_size( self ):
        return self.sde.get_size()

    def is_dir( self ):
        return self.sde.is_dir()

    def is_free( self ):
        return self.sde.is_free()

    def is_free_last( self ):
        return self.sde.is_free_last()

    def is_user_dir( self ):
        return self.sde.is_user_dir()

    def __str__( self ):
        return u"%12s - %s" % ( self.get_short_name(), self.get_long_name() )

    def __repr__( self ):
        return str( self )

class Dir:
    """
    Directory is an aggregation of directory items
    """
    def __init__( self, raw, cc=None, parent=None ):
        if len( raw ) % DE.DE_SIZE != 0:
            print "Bogus Directory data size", len( raw )

        if cc:
            self.cc = cc
        else:
            self.cc = []

        self.parent = parent
        self.raw = raw

        #---------------------------------------------------
        # Split up each directory entry
        #---------------------------------------------------
        de_list = []
        for s in range( 0, len( raw ), DE.DE_SIZE ):
            de_raw = raw[s:s+DE.DE_SIZE]
            de = DE.create( de_raw )
            de_list.append( de )

        #---------------------------------------------------
        # match up long entries with short entry
        #---------------------------------------------------
        de_list.reverse()
        self.items = []
        item = None
        for de in de_list:
            if de.is_long_filename():
                if item is None:
                    print "Long directory entry out of place"
                else:
                    item.add_lde( de )
            else:
                item = DirItem( de )
                self.items.append( item )
        self.items.reverse()

    def find_item( self, name ):
        for i in self.items:
            if name == i.get_short_name():
                return i
            if name == i.get_long_name():
                return i
        return None

    def _str( self, fltr=None ):
        s = ""
        f = filter( fltr, self.items )
        for i in f:
            s += str( i ) + "\n"
        return s
    def __repr__( self ):
        return str( self )

    def __str__( self ):
        return self._str( lambda i: not i.is_free_last() )

class FAT:
    """
    FAT file system
    """
    FAT12 = "FAT12"
    FAT16 = "FAT16"
    FAT32 = "FAT32"
    EOBPB = 0xAA55
    def __init__( self, img_file, vol_offset=0 ):
        self.f = img_file
        self.vol_offset = vol_offset

        #---------------------------------------------------
        # Read boot parameter block
        #---------------------------------------------------
        bpb = self._read( 0, 512 )
        #BS_jmpBoot               = getint( bpb, 0, 3 )
        self.BS_OEMName          = getstr( bpb, 3, 8 )
        self.BPB_bytes_per_sec   = getint( bpb, "H", 11 )
        self.BPB_sec_per_clust   = getint( bpb, "B", 13 )
        self.BPB_reserved_sec_cnt = getint( bpb, "H", 14 )
        self.BPB_num_fats        = getint( bpb, "B", 16 )
        self.BPB_root_ent_cnt    = getint( bpb, "H", 17 )
        self.BPB_total_sec16     = getint( bpb, "H", 19 )
        self.BPB_media           = getint( bpb, "B", 21 )
        self.BPB_fat_size16      = getint( bpb, "H", 22 )
        self.BPB_sec_per_trk     = getint( bpb, "H", 24 )
        self.BPB_num_heads       = getint( bpb, "H", 26 )
        self.BPB_hidden_secs     = getint( bpb, "I", 28 )
        self.BPB_total_sec32     = getint( bpb, "I", 32 )

        if self.BPB_fat_size16 != 0:
            #-----------------------------------------------
            # FAT12/16
            #-----------------------------------------------
            self.BS_drv_num         = getint( bpb, "B", 36 )
            self.BS_reserved1       = getint( bpb, "B", 37 )
            self.BS_boot_sig        = getint( bpb, "B", 38 ) #0x29
            self.BS_vol_id          = getint( bpb, "I", 39 )
            self.BS_vol_label       = getstr( bpb, 43, 11 )
            self.BS_file_sys_type   = getstr( bpb, 54, 8 )

            #-----------------------------------------------
            # fake FAT32 values to hold a place
            #-----------------------------------------------
            self.BPB_fat_size32 = 0
            self.BPB_ext_flags = 0
            self.BPB_fs_ver = 0
            self.BPB_fs_info = 0
            self.BPB_bk_boot_sec = 0
            self.BS_eobpb = FAT.EOBPB;
        else:
            #-----------------------------------------------
            # FAT32 only
            #-----------------------------------------------
            self.BPB_fat_size32      = getint( bpb, "I", 36 ) #sectors taken by 1 FAT
            self.BPB_ext_flags       = getint( bpb, "H", 40 )
            self.BPB_fs_ver          = getint( bpb, "H", 42 )
            self.BPB_root_clust      = getint( bpb, "H", 44 )
            self.BPB_fs_info         = getint( bpb, "H", 48 )
            self.BPB_bk_boot_sec     = getint( bpb, "H", 50 )
            #self.BPB_reserved        = getstr( bpb, 52, 12 )
            self.BS_drv_num          = getint( bpb, "B", 64 )
            self.BS_reserved1        = getint( bpb, "B", 65 )
            self.BS_boot_sig         = getint( bpb, "B", 66 )
            self.BS_vol_id           = getint( bpb, "I", 67 )
            self.BS_vol_label        = getstr( bpb, 71, 11 )
            self.BS_file_sys_type    = getstr( bpb, 82, 8 ) #"FAT32    "
            self.BS_eobpb            = getint( bpb, "H", 510 ) #0xaa55

            if self.BS_eobpb != FAT.EOBPB:
                print "Bogus FAT32 end of parameter block value"

        #---------------------------------------------------
        # BPB Derived values
        #---------------------------------------------------
        if self.BPB_fat_size16 != 0:
            self.fat_secs = self.BPB_fat_size16
        else:
            self.fat_secs = self.BPB_fat_size32

        if self.BPB_total_sec16 != 0:
            self.total_secs = self.BPB_total_sec16
        else:
            self.total_secs = self.BPB_total_sec32

        self.clust_size         = self.BPB_bytes_per_sec * self.BPB_sec_per_clust
        self.root_dir_secs      = ((self.BPB_root_ent_cnt * DE.DE_SIZE) + (self.BPB_bytes_per_sec - 1)) / self.BPB_bytes_per_sec
        self.first_fat_sec      = self.BPB_reserved_sec_cnt
        self.first_data_sec     = self.BPB_reserved_sec_cnt + (self.BPB_num_fats * self.fat_secs) + self.root_dir_secs
        self.first_data_offset  = self.first_data_sec * self.BPB_bytes_per_sec
        self.data_secs          = self.total_secs - self.first_data_sec
        self.data_clusts        = self.data_secs / self.BPB_sec_per_clust

        #---------------------------------------------------
        # determine FAT type and init related constants
        #---------------------------------------------------
        if self.data_clusts < 4085:
            self.fat_type = FAT.FAT12
            self.bad_clust_val = 0xFF7
            self.eoc_val = 0xFF8
            self.fat_mask = 0xFFF
            self.fat_bits = 12

        elif self.data_clusts < 65525:
            self.fat_type = FAT.FAT16
            self.bad_clust_val = 0xFFF7
            self.eoc_val = 0xFFF8
            self.fat_mask = 0xFFFF
            self.fat_bits = 16
            self.fat_entry_fmt = "H"

        else:
            self.fat_type = FAT.FAT32
            self.bad_clust_val =0x0FFFFFF7
            self.eoc_val = 0x0FFFFFF8
            self.fat_mask = 0x0FFFFFFF
            self.fat_bits = 32
            self.fat_entry_fmt = "I"

        #---------------------------------------------------
        # read the FAT, only first FAT please
        #---------------------------------------------------
        fat_offset = self.first_fat_sec * self.BPB_bytes_per_sec
        fat_size = 0
        fat_data = ""
        max_fat_size = self.fat_secs * self.BPB_bytes_per_sec

        #---------------------------------------------------
        # get FAT entries
        #---------------------------------------------------
        if self.fat_type in ( FAT.FAT16, FAT.FAT32 ):
            entry_size = struct.calcsize( self.fat_entry_fmt )
            fat_size = self.data_clusts * entry_size
            if fat_size > max_fat_size:
                print "FAT too short to contain entries for all clusters"
            fat_size = min( fat_size, max_fat_size )
            fat_data = self._read( fat_offset, fat_size )

            #determine number of entries
            max_entry_cnt = fat_size / entry_size
            entry_cnt = min( max_entry_cnt, self.data_clusts )

            #get values into FAT table
            start = 0
            self.fat = []   #MDB - TODO: fix, I'm short the last two clusters in the FAT
            for i in range( entry_cnt ):
                fat_val = getint( fat_data, self.fat_entry_fmt, start )
                fat_val = fat_val & self.fat_mask
                self.fat.append( fat_val )
                start += entry_size
        else:
            #----------------------------------------------------
            # Since FAT12 has nasty alignment issues,
            # unpack all bytes into a big long integer, then
            # chuck off 12 bits at a time to get entry values.
            #----------------------------------------------------
            fat_size = self.data_clusts + ( self.data_clusts / 2 )
            print "Fat size", fat_size
            if fat_size > max_fat_size:
                print "FAT size too short to contain entries for all clusters"
            fat_size = min( fat_size, max_fat_size )

            #unpack data into raw bytes
            fat_data = self._read( fat_offset, fat_size )
            fmt = "B" * fat_size
            bytes = struct.unpack( fmt, fat_data )

            #make big integer
            v = 0
            for i,b in enumerate( bytes ):
                v += ( b << (8*i) )

            #determine number of entries
            max_entry_cnt = ( fat_size * 8 ) / self.fat_bits
            if max_entry_cnt < self.data_clusts:
                print "FAT too short to contain entries for all clusts 2"
            entry_cnt = min( max_entry_cnt, self.data_clusts )

            #chunk off FAT values into FAT table
            self.fat = []
            for i in range( entry_cnt ):
                self.fat.append( v & self.fat_mask )
                v = v >> self.fat_bits

        #kludge off by 2 error?
        self.fat.append( self.eoc_val )
        self.fat.append( self.eoc_val )

        self.fat_size = fat_size
        self.fat_offset = fat_offset
        self.fat_raw = fat_data

        #---------------------------------------------------
        # Validate the FAT table and generate a
        # reverse lookup FAT table
        #---------------------------------------------------
        self.rfat = [ self.eoc_val for i in range( len( self.fat ) ) ]
        for ei,e in enumerate( self.fat ):

            if (e & (~self.fat_mask)) != 0:
                print "Bits set in invalid area of fat entry"
                print "fat[", ei, "] =", e, hex( e )
                continue

            if self.is_eoc( e ):
                continue

            if e >= len( self.fat ):
                print "Entry too big, out of range:"
                print "fat[", ei, "] =", e, hex( e )
                continue

            #free
            if e == 0:
                self.rfat[ ei ] = 0;
                continue

            if e < 2:
                print "Entry too little"
                print "fat[", ei, "] =", e, hex( e )
                continue

            if self.rfat[ e ] != self.eoc_val:
                print "Multi mapped entry", e, hex( e )
                print "fat[", ei, "] =", e, hex( e )

            self.rfat[ e ] = ei

        #get root directory
        self.root_raw, cc = self.get_root_data()
        self.vol_label = ShortDE( self.root_raw[:DE.DE_SIZE]).get_short_name()
        self.root_dir = Dir( self.root_raw[DE.DE_SIZE:], cc )
        self.cur_dir = self.root_dir

        self.clust2file = [ [] for i in range( len( self.fat ) ) ]
        #self.traverse_dir( self.root_dir )

    def traverse_dir( self, basedir, depth=0 ):
        #print "*"*80
        #print "Traverse"
        #print basedir
        #print "*"*80
        for i,item in enumerate( basedir.items ):
            if not item.is_free():
                if item.is_dir():
                    if not item.is_user_dir():
                        continue

                    c = item.sde.get_clust()
                    if c < 2:
                        print depth, i, "Clust check", name
                        continue

                    name = str( item )
                    data,cc = self.get_file_data( c )
                    subdir = Dir( data, cc )
                    self.traverse_dir( subdir, depth=depth+1)
                else:
                    c = item.sde.get_clust()
                    #print "File", str( item ), 'at cluster', c
                    cc = self.get_clust_chain( c )
                    for idx in cc:
                        if not self.is_eoc( idx ):
                            self.clust2file[ idx ].append( item )


    def _read( self, start, size ):
        #Adjust start for volume offset
        start += self.vol_offset

        #For raw file access mode, must read sector boundary
        sec_sz = 512

        align_size = size

        #align start
        align_start_offset = ( start % sec_sz )
        align_start = start - align_start_offset
        align_size += align_start_offset

        #align end
        end = start + size
        align_end_offset = end % sec_sz
        if align_end_offset > 0:
            align_size += ( sec_sz - align_end_offset )

        #aligned read
        #print "read start=%08x, size=%08x" % ( align_start, align_size )
        self.f.seek( align_start )
        data = self.f.read( align_size )

        #return desired section within the aligned data
        return data[ align_start_offset:align_start_offset + size ]

    def cd( self, name ):
        item = self.cur_dir.find_item( name )
        if not item:
            print "Directory not found", repr( name )
            return
        c = item.sde.get_clust()
        if c == 0:
            print "Root dir"
            self.cur_dir = self.root_dir
        else:
            print "Directory", name, "at cluster", c
            data,cc = self.get_file_data( c )
            self.cur_dir = Dir( data, cc )

    def get_root_data( self ):
        if self.fat_type is FAT.FAT32:
            self.root_offset = self.offset_of_clust( self.BPB_root_clust )
            data, cc = self.get_file_data( self.BPB_root_clust )
            return data, cc
        else:
            root_sec = self.BPB_reserved_sec_cnt + (self.BPB_num_fats * self.fat_secs)
            self.root_offset = root_sec * self.BPB_bytes_per_sec
            root_size = self.root_dir_secs * self.BPB_bytes_per_sec
            data = self._read( self.root_offset, root_size )
            return data, []

    def get_clust_chain( self, c ):
        if c < 2:
            return []
        cc = [ c ]
        while self.is_eoc( c ) is False:
            c = self.fat[ c ]
            cc.append( c )
        return cc

    def get_clust_data( self, c ):
        off = self.offset_of_clust( c )
        return self._read( off, self.clust_size )

    def get_file_data( self, c ):
        """
        c = starting cluster index
        return ( data, cluster_chain )
        """
        data = ""
        cc = self.get_clust_chain( c )
        for c in cc:
            if self.is_eoc( c ):
                break
            data += self.get_clust_data( c )
        return data, cc

    def offset_of_clust( self, c ):
        """
        c = cluster index
        return volume byte offset of start of cluster c
        """
        if c == 0:
            print "root dir"
            return 0

        if c < 2:
            print "foobacious cluster index"
            return -1

        if self.is_eoc( c ):
            return 0

        return self.first_data_offset + ( (c-2) * self.clust_size )

    def cc_vol_offset( self, cc, offset ):
        """
        cc = cluster chain list
        offset = byte offset in cluster chain
        return volume byte offset of 'offset' in 'cc'
        """
        idx = offset / self.clust_size
        if idx < len( cc ):
            off  = self.offset_of_clust( cc[ idx ] );
            off += offset % self.clust_size;
            return off
        return 0

    def get_fat_type( self ):
        return self.fat_type

    def is_eoc( self, fat_val ):
        return fat_val >= self.eoc_val

    def __repr__( self ):
        return str( self )

    def __str__( self ):
        s = ""
        prop = dir( self )
        for p in prop:
            if p.startswith( "BPB_" ) or p.startswith( "BS_" ):
                s += "%-24s : %s\n" % ( p, repr( getattr( self, p ) ) )
        return s

class Interp:
    """
    Command line interpreter
    """
    def __init__( self, fat ):
        self.fat = fat

    @staticmethod
    def _test_text_to_args():
        input = " chain         20100401_193419.txt"
        expected = [ "chain", "20100401_193419.txt" ]
        result = Interp.text_to_args( input )
        print "expected", expected
        print "result", result
        print "Match:", expected == result

        input = r'extract -c -a 100 "A long file name.txt" "c:\program files\output.txt" > redir.txt'
        expected = [ "extract", "-c", "-a", "100", "A long file name.txt", "c:\program files\output.txt", ">", "redir.txt" ]
        result = Interp.text_to_args( input )
        print "expected", expected
        print "result", result
        print "Match:", expected == result

    @staticmethod
    def text_to_args( input ):
        """
        Convert command line text to args list

        E.G. input of:
        "extract -c -a 100 "A long file name.txt" "c:\program files\output.txt" > redir.txt

        Returns:
        [ "extract", "-c", "-a", "100", "A long file name.txt", "c:\program files\output.txt", ">", "redir.txt" ]
        """
        input = input.strip()
        raw_args = input.split(' ')

        lead = None
        combos = ( '"', '"' )
        args = []
        for ra in raw_args:
            if lead:
                end = ra[-1]
                if end in combos:
                    args[-1] += " " + ra[:-1]
                    lead = None
                else:
                    args[-1] += " " + ra
            else:
                args.append( "" )
                if len( ra ) > 0:
                    beg = ra[0]
                    if beg in combos:
                        lead = beg
                        args[-1] += ra[1:]
                    else:
                        args[-1] += ra

        #remove empty args
        ret = []
        for a in args:
            if a:
                ret.append( a )
        return ret

    def _consec_report( self, c, redir=sys.stdout ):
        cc = self.fat.get_clust_chain( c )
        start = None
        cnt = 0
        consec = []
        for i in cc:
            if start:
                if i != start + cnt:
                    consec.append( ( start, cnt ) )
                    cnt = 1
                    start = i
                else:
                    cnt += 1
            else:
                start = i
                cnt = 1

        print >> redir, "Consecutive Cluster Report"
        print >> redir, "Start cluster          , Cluster count"
        for s,c in consec:
            print >> redir, "%10u (0x%08X), %u" % ( s, s, c )

    def _get_clust( self, c ):
        data = self.fat.get_clust_data( c )
        off = self.fat.offset_of_clust( c )
        return ( off, data )

    def _get_diritem( self, args ):
        name = " ".join( args )
        i = self.fat.cur_dir.find_item( name )
        return i

    def _make_clust( self, c, redir=sys.stdout ):
        s = ""
        ( off, data ) = self._get_clust( c )
        print >> redir, "FAT cluster", c, "data len", len( data ), "offset", off
        if self.fat.is_eoc( c ):
            print >> redir, "End of chain"
        else:
            print_bin( data, offset=off, redir=redir )

    def chain_idx( self, c, redir=sys.stdout ): #MDB - use None as redir default?
        cc = self.fat.get_clust_chain( c )
        self.cc = cc
        if not cc:
            print >> redir, "No cluster chain at cluster", c, hex( c )
            return

        print >> redir, "Cluster index        , Offset in Volume"
        for c in cc:
            off = self.fat.offset_of_clust( c )
            print >> redir, "%10u 0x%08X, %10u 0x%08X" % ( c, c, off, off )

    #-------------------------------------------------------
    # User commands. Must start with _cmd_
    #-------------------------------------------------------

    def _cmd_bin( self, args, redir ):
        """
        Output directory item as binary data
        """
        i = self._get_diritem( args )
        if i:
            c = i.sde.get_clust()
            cc = self.fat.get_clust_chain( c )
            if not cc:
                print >> redir, "No cluster chain at cluster", c, hex( c )
            else:
                for c in cc:
                    self._make_clust( c, redir=redir )
        else:
            print >> redir, "Not found"

    def _cmd_cd( self, args, redir ):
        """
        Change directory to args[0]
        """
        name = " ".join( args )
        self.fat.cd( name )
        print >> redir, self.fat.cur_dir

    def _cmd_cdroot( self, args, redir ):
        """
        Change to root directory.
        """
        self.fat.cur_dir = self.fat.root_dir
        print >> redir, self.fat.cur_dir

    def _cmd_chain( self, args, redir ):
        """
        Output cluster chain for directory item args[0]
        """
        i = self._get_diritem( args )
        if i:
            c = i.sde.get_clust()
            self.chain_idx( c, redir=redir )
        else:
            print >> redir, "Not found"

    def _cmd_chain_idx( self, args, redir ):
        """
        Output cluster chain starting with cluster index args[0]
        """
        ( valid, idx ) = parse_int( args[0] )
        if valid:
            self.chain_idx( idx, redir=redir )

    def _cmd_clust( self, args, redir ):
        """
        Output cluster index at args[0] as binary data
        """
        ( valid, c ) = parse_int( args[0] )
        if valid and c >= 2:
            self._make_clust( c, redir=redir )
        else:
            print >> redir, "Invalid cluster", repr( c )

    def _cmd_clustfile( self, args, redir ):
        ( valid, c ) = parse_int( args[0] )
        if valid and c >= 2:
            item_list = self.fat.clust2file[ c ]
            if item_list:
                for item in item_list:
                    print >> redir, item
            else:
                print >> redir, "No directory entry found chained to clust"
        else:
            print >> redir, "Invalid cluster", repr( c )

    def _cmd_consec( self, args, redir ):
        """
        Consecutive cluster report for directory item arg[0]
        """
        i = self._get_diritem( args )
        if i:
            c = i.sde.get_clust()
            self._consec_report( c, redir=redir )
        else:
            print >> redir, "Not found"

    def _cmd_consec_idx( self, args, redir ):
        """
        Consecutive cluster report starting at cluster index in args[0]
        """
        help = "Syntax: consec_idx clust_index"
        if len( args ) != 1:
            print >> redir, "Got", len( args ), "args"
            print >> redir, args
            print >> redir, help
            return

        ( valid, c ) = parse_int( args[0] )
        if valid and c >= 2:
            self._consec_report( c, redir=redir )

    def _cmd_de( self, args, redir ):
        """
        Dump byte offset in arg[0] as a directory entry
        """
        help = "Syntax: de volume_offset"
        if len( args ) != 1:
            print >> redir, "Got", len( args ), "args"
            print >> redir, args
            print >> redir, help
            return

        ( valid, offset ) = parse_int( args[0] )
        de_raw = fat._read( offset, DE.DE_SIZE )
        de = DE.create( de_raw )
        print de

    def _cmd_extract( self, args, redir ):
        """
        Extract file arg[0] from filesystem and write to arg[1]
        """
        help = "Syntax: extract filename outname"
        if len( args ) == 1:
            args.append( args[0] )

        if len( args ) != 2:
            print >> redir, "Got", len( args ), "args"
            print >> redir, args
            print >> redir, help
            return

        infilename = args[0]
        outfilename = args[1]

        #Open output file
        out = None
        try:
            out = open( outfilename, 'wb' )
        except:
            print >> redir, "Couldn't open up output file", repr( outfilename )
            print >> redir, help
            return

        i = self._get_diritem( [ infilename ] )
        if i:
            c = i.sde.get_clust()
            cc = self.fat.get_clust_chain( c )
            if not cc:
                print >> redir, "No cluster chain at cluster", c, hex( c )
            else:
                size = i.sde.get_size()
                for c in cc:
                    ( off, data ) = self._get_clust( c )
                    if size < len( data ):
                        data = data[:size]
                    out.write( data )
                    size -= len( data )

        else:
            print >> redir, repr( infilename ), "not found"


    def _cmd_fatbin( self, args, redir ):
        """
        Dump FAT binary as text
        """
        data = self.fat.fat_raw
        print_bin( data, offset=fat.fat_offset, offset2=0, redir=redir )

    def _cmd_help( self, args, redir ):
        """
        Print names of all available commands
        """
        cmd_prefix = "_cmd_"
        prefix_len = len( cmd_prefix )
        items = dir( self )
        for i in items:
            if i.startswith( "_cmd_" ):
                doc = getattr( self, i ).__doc__
                if doc:
                    doc = doc.strip()
                else:
                    doc = ""
                print >> redir, " %-15s %s" % ( i[ prefix_len: ], doc )
        print >> redir, "\n"

    def _cmd_info( self, args, redir ):
        """
        Print all info about a directory item args[0]
        """
        i = self._get_diritem( args )
        if i:
            print >> redir, i.sde
        else:
            print >> redir, "Not found"

    def _cmd_rootbin( self, args, redir ):
        """
        Output rootdir binary data as text
        """
        data = self.fat.root_raw
        print_bin( data, redir=redir, offset=fat.root_offset, offset2=0 )

    def _cmd_text( self, args, redir ):
        """
        Output contents of directory item args[0] as text
        """
        i = self._get_diritem( args )
        if i:
            c = i.sde.get_clust()
            data,cc = self.fat.get_file_data( c )
            data = data[:i.get_size()]
            print >> redir, data
        else:
            print >> redir, "Not found"

    def execute( self, input ):
        """
        input = "cmd [arg ..] [> redirect]"
        command with optional args and redirection
        >  output new file
        """
        items = Interp.text_to_args( input )

        #---------------------------------------------------
        # look for redirection
        #---------------------------------------------------
        redir = ""
        redir_file = None
        for i,item in enumerate( items ):
            if item == ">":
                redir = " ".join( items[i+1:] )
                #print "REDIR:", repr( redir )
                try:
                    redir_file = open( redir, 'wb' )
                except:
                    print "Couldn't open redir file", repr( redir )
                break
        else:
            i += 1

        cmd = items[0]
        args = items[1:i]

        if redir_file:
            r = redir_file
        else:
            r = sys.stdout

        funcname = "_cmd_" + cmd
        try:
            func = getattr( self, funcname )
            if not callable( func ):
                return False
        except:
            return False

        #print "CMD:", cmd
        #print "ARG:", args

        func( args, r )

        if redir_file:
            redir_file.close()

        return True

class Part:
    """
    Master Boot Record Primary Partition
    """
    STAT_BOOTABLE   = 0x80
    def __init__( self, raw ):
        self.status     = getint( raw, "B", 0  )
        self.part_type  = getint( raw, "B", 4  )
        self.lba_start  = getint( raw, "I", 8  )
        self.num_blks   = getint( raw, "I", 12 )

    def is_valid( self ):
        end = self.lba_start + self.num_blks
        if end >= (1<<32):
            return False

        return self.num_blks > 0 and self.lba_start > 0 and self.part_type > 0

    def __repr__( self ):
        return str( self )

    def __str__( self ):
        s = ""
        s += "status    " + str( self.status ) + "\n"
        s += "part_type " + str( self.part_type ) + " " + hex( self.part_type ) + "\n"
        s += "lba_start " + str( self.lba_start ) + " " + hex( self.lba_start ) + "\n"
        s += "num_blks  " + str( self.num_blks )  + " " + hex( self.num_blks ) + "\n"
        return s

class MBR:
    """
    Master Boot Record
    """
    MBR_SIG         = 0xAA55
    def __init__( self, raw ):
        #self.code               = 0 .. 440
        self.disk_sig            = getint( raw, "I", 440 )
        self.usually_null        = getint( raw, "H", 444 )

        #---------------------------------------------------
        # partition table
        #---------------------------------------------------
        self.parts = []
        start = 446
        part_size = 16
        for i in range( 4 ):
            p = Part( raw[ start:start+part_size ] )
            self.parts.append( p )
            start += part_size

        self.mbr_sig             = getint( raw, "H", 510 ) #0xaa55

    def is_valid( self ):
        mbr_valid = self.mbr_sig == MBR.MBR_SIG
        part_valid = False
        for p in self.parts:
            part_valid = part_valid or p.is_valid()

        return mbr_valid and part_valid

    def __repr__( self ):
        return str( self )

    def __str__( self ):
        s = ""
        s += "disk_sig  " + str( self.disk_sig )     + " " + hex( self.disk_sig )     + "\n"
        s += "nulls     " + str( self.usually_null ) + " " + hex( self.usually_null ) + "\n"
        s += "mbr_sig   " + str( self.mbr_sig )      + " " + hex( self.mbr_sig )      + "\n"
        for i,p in enumerate( self.parts ):
            s += "Partition " + str( i ) + "\n"
            psp = str( p ).split( "\n" )
            s += "    " + "\n    ".join( psp ) + "\n"
        return s

def recurse_extract( fat, base ):
    """
    Take a FAT at the current directory and start copying every
    file and subdirectory into an analogous file and directory under
    the base folder.
    """
    if not os.path.exists( base ):
        #print "Make dir", base
        os.mkdir( base )

    for item in fat.cur_dir.items:
        name = item.get_long_name()
        if not name:
            name = item.get_short_name()

        if name.startswith( "<FREE>" ):
            continue

        if item.is_dir():
            if item.is_user_dir():
                subdir = os.path.join( base, name )
                fat.cd( name )
                recurse_extract( fat, subdir )
                fat.cd( ".." )
        else:
            data,cc = fat.get_file_data( item.sde.get_clust() )
            fname = os.path.join( base, name )
            #print "Extract file", fname
            f = open( fname, 'wb' )
            f.write( data[:item.get_size()] )
            f.close()


if __name__ == "__main__":
    #Interp._test_text_to_args()
    import argparse

    parser = argparse.ArgumentParser( description="FAT file system explorer", epilog="" )
    parser.add_argument("file_vol_name", type=str, help=r"binary file with FAT image or volume, '\\.\<vol_letter>:', '\\.\F:' for volume drive F" )
    parser.add_argument("-i", "--interactive", action="store_true", help="Interactively explore file system" )
    parser.add_argument("-x", "--extract", type=str, default='', help="Base directory to extract file system data" )

    args = parser.parse_args()
    #print args

    #-------------------------------------------------------
    # To open a volume use the following for the filename
    #    "\\.\<vol_letter>:", "\\.\F:" for the F drive.
    #-------------------------------------------------------
    f = open( args.file_vol_name, 'rb' )

    #-------------------------------------------------------
    # read master boot record for partition tables
    #-------------------------------------------------------
    raw = f.read( 512 )
    mbr = MBR( raw )

    if mbr.is_valid():
        print "MBR"
        print mbr
        print
        print "Enter the number of the partition you want to evaluate:",
        input = raw_input()
        ( valid, idx ) = parse_int( input )
        if valid and idx >= 0 and idx < len( mbr.parts ):
            part_start = mbr.parts[idx].lba_start * 512
        else:
            print "Ignoring partition table, treating volume as one partition"
            part_start = 0
    else:
        print "MBR invalid, treating as single partition"
        part_start = 0

    #extract all files to local directory
    if args.extract:
        fat = FAT( f, part_start )
        base_dir = sys.argv[2]
        recurse_extract( fat, args.extract )

    #interactive command line
    if args.interactive:
        fat = FAT( f, part_start )
        print fat

        interp = Interp( fat )
        print "Type help to get list of commands"

        while True:
            print "fat>",
            input = raw_input()
            if "quit" == input or "exit" == input:
                sys.exit(0)
                break

            if input:
                ret = interp.execute( input )
                if ret is False:
                    #--------------------------------------------
                    # interp didn't handle, pass along to python
                    #--------------------------------------------
                    try:
                        exec( input )
                    except:
                        print "Python didn't like that input"
                        print sys.exc_info()[0]

            else:
                print fat.cur_dir

